// modules are defined as an array
// [ module function, map of requires ]
//
// map of requires is short require name -> numeric require
//
// anything defined in a previous bundle is accessed via the
// orig method which is the require for previous bundles
parcelRequire = (function (modules, cache, entry, globalName) {
  // Save the require from previous bundle to this closure if any
  var previousRequire = typeof parcelRequire === 'function' && parcelRequire;
  var nodeRequire = typeof require === 'function' && require;

  function newRequire(name, jumped) {
    if (!cache[name]) {
      if (!modules[name]) {
        // if we cannot find the module within our internal map or
        // cache jump to the current global require ie. the last bundle
        // that was added to the page.
        var currentRequire = typeof parcelRequire === 'function' && parcelRequire;
        if (!jumped && currentRequire) {
          return currentRequire(name, true);
        }

        // If there are other bundles on this page the require from the
        // previous one is saved to 'previousRequire'. Repeat this as
        // many times as there are bundles until the module is found or
        // we exhaust the require chain.
        if (previousRequire) {
          return previousRequire(name, true);
        }

        // Try the node require function if it exists.
        if (nodeRequire && typeof name === 'string') {
          return nodeRequire(name);
        }

        var err = new Error('Cannot find module \'' + name + '\'');
        err.code = 'MODULE_NOT_FOUND';
        throw err;
      }

      localRequire.resolve = resolve;
      localRequire.cache = {};

      var module = cache[name] = new newRequire.Module(name);

      modules[name][0].call(module.exports, localRequire, module, module.exports, this);
    }

    return cache[name].exports;

    function localRequire(x){
      return newRequire(localRequire.resolve(x));
    }

    function resolve(x){
      return modules[name][1][x] || x;
    }
  }

  function Module(moduleName) {
    this.id = moduleName;
    this.bundle = newRequire;
    this.exports = {};
  }

  newRequire.isParcelRequire = true;
  newRequire.Module = Module;
  newRequire.modules = modules;
  newRequire.cache = cache;
  newRequire.parent = previousRequire;
  newRequire.register = function (id, exports) {
    modules[id] = [function (require, module) {
      module.exports = exports;
    }, {}];
  };

  var error;
  for (var i = 0; i < entry.length; i++) {
    try {
      newRequire(entry[i]);
    } catch (e) {
      // Save first error but execute all entries
      if (!error) {
        error = e;
      }
    }
  }

  if (entry.length) {
    // Expose entry point to Node, AMD or browser globals
    // Based on https://github.com/ForbesLindesay/umd/blob/master/template.js
    var mainExports = newRequire(entry[entry.length - 1]);

    // CommonJS
    if (typeof exports === "object" && typeof module !== "undefined") {
      module.exports = mainExports;

    // RequireJS
    } else if (typeof define === "function" && define.amd) {
     define(function () {
       return mainExports;
     });

    // <script>
    } else if (globalName) {
      this[globalName] = mainExports;
    }
  }

  // Override the current require with this new one
  parcelRequire = newRequire;

  if (error) {
    // throw error from earlier, _after updating parcelRequire_
    throw error;
  }

  return newRequire;
})({"or4r":[function(require,module,exports) {
var global = arguments[3];
/**
 * lodash (Custom Build) <https://lodash.com/>
 * Build: `lodash modularize exports="npm" -o ./`
 * Copyright jQuery Foundation and other contributors <https://jquery.org/>
 * Released under MIT license <https://lodash.com/license>
 * Based on Underscore.js 1.8.3 <http://underscorejs.org/LICENSE>
 * Copyright Jeremy Ashkenas, DocumentCloud and Investigative Reporters & Editors
 */

/** Used as the `TypeError` message for "Functions" methods. */
var FUNC_ERROR_TEXT = 'Expected a function';

/** Used as references for various `Number` constants. */
var NAN = 0 / 0;

/** `Object#toString` result references. */
var symbolTag = '[object Symbol]';

/** Used to match leading and trailing whitespace. */
var reTrim = /^\s+|\s+$/g;

/** Used to detect bad signed hexadecimal string values. */
var reIsBadHex = /^[-+]0x[0-9a-f]+$/i;

/** Used to detect binary string values. */
var reIsBinary = /^0b[01]+$/i;

/** Used to detect octal string values. */
var reIsOctal = /^0o[0-7]+$/i;

/** Built-in method references without a dependency on `root`. */
var freeParseInt = parseInt;

/** Detect free variable `global` from Node.js. */
var freeGlobal = typeof global == 'object' && global && global.Object === Object && global;

/** Detect free variable `self`. */
var freeSelf = typeof self == 'object' && self && self.Object === Object && self;

/** Used as a reference to the global object. */
var root = freeGlobal || freeSelf || Function('return this')();

/** Used for built-in method references. */
var objectProto = Object.prototype;

/**
 * Used to resolve the
 * [`toStringTag`](http://ecma-international.org/ecma-262/7.0/#sec-object.prototype.tostring)
 * of values.
 */
var objectToString = objectProto.toString;

/* Built-in method references for those with the same name as other `lodash` methods. */
var nativeMax = Math.max,
    nativeMin = Math.min;

/**
 * Gets the timestamp of the number of milliseconds that have elapsed since
 * the Unix epoch (1 January 1970 00:00:00 UTC).
 *
 * @static
 * @memberOf _
 * @since 2.4.0
 * @category Date
 * @returns {number} Returns the timestamp.
 * @example
 *
 * _.defer(function(stamp) {
 *   console.log(_.now() - stamp);
 * }, _.now());
 * // => Logs the number of milliseconds it took for the deferred invocation.
 */
var now = function() {
  return root.Date.now();
};

/**
 * Creates a debounced function that delays invoking `func` until after `wait`
 * milliseconds have elapsed since the last time the debounced function was
 * invoked. The debounced function comes with a `cancel` method to cancel
 * delayed `func` invocations and a `flush` method to immediately invoke them.
 * Provide `options` to indicate whether `func` should be invoked on the
 * leading and/or trailing edge of the `wait` timeout. The `func` is invoked
 * with the last arguments provided to the debounced function. Subsequent
 * calls to the debounced function return the result of the last `func`
 * invocation.
 *
 * **Note:** If `leading` and `trailing` options are `true`, `func` is
 * invoked on the trailing edge of the timeout only if the debounced function
 * is invoked more than once during the `wait` timeout.
 *
 * If `wait` is `0` and `leading` is `false`, `func` invocation is deferred
 * until to the next tick, similar to `setTimeout` with a timeout of `0`.
 *
 * See [David Corbacho's article](https://css-tricks.com/debouncing-throttling-explained-examples/)
 * for details over the differences between `_.debounce` and `_.throttle`.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Function
 * @param {Function} func The function to debounce.
 * @param {number} [wait=0] The number of milliseconds to delay.
 * @param {Object} [options={}] The options object.
 * @param {boolean} [options.leading=false]
 *  Specify invoking on the leading edge of the timeout.
 * @param {number} [options.maxWait]
 *  The maximum time `func` is allowed to be delayed before it's invoked.
 * @param {boolean} [options.trailing=true]
 *  Specify invoking on the trailing edge of the timeout.
 * @returns {Function} Returns the new debounced function.
 * @example
 *
 * // Avoid costly calculations while the window size is in flux.
 * jQuery(window).on('resize', _.debounce(calculateLayout, 150));
 *
 * // Invoke `sendMail` when clicked, debouncing subsequent calls.
 * jQuery(element).on('click', _.debounce(sendMail, 300, {
 *   'leading': true,
 *   'trailing': false
 * }));
 *
 * // Ensure `batchLog` is invoked once after 1 second of debounced calls.
 * var debounced = _.debounce(batchLog, 250, { 'maxWait': 1000 });
 * var source = new EventSource('/stream');
 * jQuery(source).on('message', debounced);
 *
 * // Cancel the trailing debounced invocation.
 * jQuery(window).on('popstate', debounced.cancel);
 */
function debounce(func, wait, options) {
  var lastArgs,
      lastThis,
      maxWait,
      result,
      timerId,
      lastCallTime,
      lastInvokeTime = 0,
      leading = false,
      maxing = false,
      trailing = true;

  if (typeof func != 'function') {
    throw new TypeError(FUNC_ERROR_TEXT);
  }
  wait = toNumber(wait) || 0;
  if (isObject(options)) {
    leading = !!options.leading;
    maxing = 'maxWait' in options;
    maxWait = maxing ? nativeMax(toNumber(options.maxWait) || 0, wait) : maxWait;
    trailing = 'trailing' in options ? !!options.trailing : trailing;
  }

  function invokeFunc(time) {
    var args = lastArgs,
        thisArg = lastThis;

    lastArgs = lastThis = undefined;
    lastInvokeTime = time;
    result = func.apply(thisArg, args);
    return result;
  }

  function leadingEdge(time) {
    // Reset any `maxWait` timer.
    lastInvokeTime = time;
    // Start the timer for the trailing edge.
    timerId = setTimeout(timerExpired, wait);
    // Invoke the leading edge.
    return leading ? invokeFunc(time) : result;
  }

  function remainingWait(time) {
    var timeSinceLastCall = time - lastCallTime,
        timeSinceLastInvoke = time - lastInvokeTime,
        result = wait - timeSinceLastCall;

    return maxing ? nativeMin(result, maxWait - timeSinceLastInvoke) : result;
  }

  function shouldInvoke(time) {
    var timeSinceLastCall = time - lastCallTime,
        timeSinceLastInvoke = time - lastInvokeTime;

    // Either this is the first call, activity has stopped and we're at the
    // trailing edge, the system time has gone backwards and we're treating
    // it as the trailing edge, or we've hit the `maxWait` limit.
    return (lastCallTime === undefined || (timeSinceLastCall >= wait) ||
      (timeSinceLastCall < 0) || (maxing && timeSinceLastInvoke >= maxWait));
  }

  function timerExpired() {
    var time = now();
    if (shouldInvoke(time)) {
      return trailingEdge(time);
    }
    // Restart the timer.
    timerId = setTimeout(timerExpired, remainingWait(time));
  }

  function trailingEdge(time) {
    timerId = undefined;

    // Only invoke if we have `lastArgs` which means `func` has been
    // debounced at least once.
    if (trailing && lastArgs) {
      return invokeFunc(time);
    }
    lastArgs = lastThis = undefined;
    return result;
  }

  function cancel() {
    if (timerId !== undefined) {
      clearTimeout(timerId);
    }
    lastInvokeTime = 0;
    lastArgs = lastCallTime = lastThis = timerId = undefined;
  }

  function flush() {
    return timerId === undefined ? result : trailingEdge(now());
  }

  function debounced() {
    var time = now(),
        isInvoking = shouldInvoke(time);

    lastArgs = arguments;
    lastThis = this;
    lastCallTime = time;

    if (isInvoking) {
      if (timerId === undefined) {
        return leadingEdge(lastCallTime);
      }
      if (maxing) {
        // Handle invocations in a tight loop.
        timerId = setTimeout(timerExpired, wait);
        return invokeFunc(lastCallTime);
      }
    }
    if (timerId === undefined) {
      timerId = setTimeout(timerExpired, wait);
    }
    return result;
  }
  debounced.cancel = cancel;
  debounced.flush = flush;
  return debounced;
}

/**
 * Checks if `value` is the
 * [language type](http://www.ecma-international.org/ecma-262/7.0/#sec-ecmascript-language-types)
 * of `Object`. (e.g. arrays, functions, objects, regexes, `new Number(0)`, and `new String('')`)
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is an object, else `false`.
 * @example
 *
 * _.isObject({});
 * // => true
 *
 * _.isObject([1, 2, 3]);
 * // => true
 *
 * _.isObject(_.noop);
 * // => true
 *
 * _.isObject(null);
 * // => false
 */
function isObject(value) {
  var type = typeof value;
  return !!value && (type == 'object' || type == 'function');
}

/**
 * Checks if `value` is object-like. A value is object-like if it's not `null`
 * and has a `typeof` result of "object".
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is object-like, else `false`.
 * @example
 *
 * _.isObjectLike({});
 * // => true
 *
 * _.isObjectLike([1, 2, 3]);
 * // => true
 *
 * _.isObjectLike(_.noop);
 * // => false
 *
 * _.isObjectLike(null);
 * // => false
 */
function isObjectLike(value) {
  return !!value && typeof value == 'object';
}

/**
 * Checks if `value` is classified as a `Symbol` primitive or object.
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a symbol, else `false`.
 * @example
 *
 * _.isSymbol(Symbol.iterator);
 * // => true
 *
 * _.isSymbol('abc');
 * // => false
 */
function isSymbol(value) {
  return typeof value == 'symbol' ||
    (isObjectLike(value) && objectToString.call(value) == symbolTag);
}

/**
 * Converts `value` to a number.
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to process.
 * @returns {number} Returns the number.
 * @example
 *
 * _.toNumber(3.2);
 * // => 3.2
 *
 * _.toNumber(Number.MIN_VALUE);
 * // => 5e-324
 *
 * _.toNumber(Infinity);
 * // => Infinity
 *
 * _.toNumber('3.2');
 * // => 3.2
 */
function toNumber(value) {
  if (typeof value == 'number') {
    return value;
  }
  if (isSymbol(value)) {
    return NAN;
  }
  if (isObject(value)) {
    var other = typeof value.valueOf == 'function' ? value.valueOf() : value;
    value = isObject(other) ? (other + '') : other;
  }
  if (typeof value != 'string') {
    return value === 0 ? value : +value;
  }
  value = value.replace(reTrim, '');
  var isBinary = reIsBinary.test(value);
  return (isBinary || reIsOctal.test(value))
    ? freeParseInt(value.slice(2), isBinary ? 2 : 8)
    : (reIsBadHex.test(value) ? NAN : +value);
}

module.exports = debounce;

},{}],"WEtf":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
// device sniffing for mobile
var isMobile = {
  android: function android() {
    return navigator.userAgent.match(/Android/i);
  },
  blackberry: function blackberry() {
    return navigator.userAgent.match(/BlackBerry/i);
  },
  ios: function ios() {
    return navigator.userAgent.match(/iPhone|iPad|iPod/i);
  },
  opera: function opera() {
    return navigator.userAgent.match(/Opera Mini/i);
  },
  windows: function windows() {
    return navigator.userAgent.match(/IEMobile/i);
  },
  any: function any() {
    return isMobile.android() || isMobile.blackberry() || isMobile.ios() || isMobile.opera() || isMobile.windows();
  }
};
var _default = isMobile;
exports.default = _default;
},{}],"hZBy":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.select = select;
exports.selectAll = selectAll;
exports.find = find;
exports.removeClass = removeClass;
exports.addClass = addClass;
exports.hasClass = hasClass;
exports.jumpTo = jumpTo;

function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance"); }

function _iterableToArray(iter) { if (Symbol.iterator in Object(iter) || Object.prototype.toString.call(iter) === "[object Arguments]") return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = new Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } }

// DOM helper functions
// public
function select(selector) {
  return document.querySelector(selector);
}

function selectAll(selector) {
  var parent = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : document;
  return _toConsumableArray(parent.querySelectorAll(selector));
}

function find(el, selector) {
  return _toConsumableArray(el.querySelectorAll(selector));
}

function removeClass(el, className) {
  if (el.classList) el.classList.remove(className);else el.className = el.className.replace(new RegExp("(^|\\b)".concat(className.split(' ').join('|'), "(\\b|$)"), 'gi'), ' ');
}

function addClass(el, className) {
  if (el.classList) el.classList.add(className);else el.className = "".concat(el.className, " ").concat(className);
}

function hasClass(el, className) {
  if (el.classList) return el.classList.contains(className);
  return new RegExp("(^| )".concat(className, "( |$)"), 'gi').test(el.className);
}

function jumpTo(el, offset) {
  offset = offset || 0;
  var top = el.getBoundingClientRect().top + offset;
  var scrollTop = window.pageYOffset || document.documentElement.scrollTop;
  var destY = scrollTop + top;
  window.scrollTo(0, destY);
}
},{}],"U9xJ":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = linkFix;

var _dom = require("./dom");

/**
 * Fixes target blanks links
 */
function linkFix() {
  var links = (0, _dom.selectAll)("[target='_blank']");
  links.forEach(function (link) {
    return link.setAttribute("rel", "noopener");
  });
}
},{"./dom":"hZBy"}],"CRRU":[function(require,module,exports) {
/**
 * Copyright 2016 Google Inc. All Rights Reserved.
 *
 * Licensed under the W3C SOFTWARE AND DOCUMENT NOTICE AND LICENSE.
 *
 *  https://www.w3.org/Consortium/Legal/2015/copyright-software-and-document
 *
 */
(function() {
'use strict';

// Exit early if we're not running in a browser.
if (typeof window !== 'object') {
  return;
}

// Exit early if all IntersectionObserver and IntersectionObserverEntry
// features are natively supported.
if ('IntersectionObserver' in window &&
    'IntersectionObserverEntry' in window &&
    'intersectionRatio' in window.IntersectionObserverEntry.prototype) {

  // Minimal polyfill for Edge 15's lack of `isIntersecting`
  // See: https://github.com/w3c/IntersectionObserver/issues/211
  if (!('isIntersecting' in window.IntersectionObserverEntry.prototype)) {
    Object.defineProperty(window.IntersectionObserverEntry.prototype,
      'isIntersecting', {
      get: function () {
        return this.intersectionRatio > 0;
      }
    });
  }
  return;
}


/**
 * A local reference to the document.
 */
var document = window.document;


/**
 * An IntersectionObserver registry. This registry exists to hold a strong
 * reference to IntersectionObserver instances currently observing a target
 * element. Without this registry, instances without another reference may be
 * garbage collected.
 */
var registry = [];

/**
 * The signal updater for cross-origin intersection. When not null, it means
 * that the polyfill is configured to work in a cross-origin mode.
 * @type {function(DOMRect|ClientRect, DOMRect|ClientRect)}
 */
var crossOriginUpdater = null;

/**
 * The current cross-origin intersection. Only used in the cross-origin mode.
 * @type {DOMRect|ClientRect}
 */
var crossOriginRect = null;


/**
 * Creates the global IntersectionObserverEntry constructor.
 * https://w3c.github.io/IntersectionObserver/#intersection-observer-entry
 * @param {Object} entry A dictionary of instance properties.
 * @constructor
 */
function IntersectionObserverEntry(entry) {
  this.time = entry.time;
  this.target = entry.target;
  this.rootBounds = ensureDOMRect(entry.rootBounds);
  this.boundingClientRect = ensureDOMRect(entry.boundingClientRect);
  this.intersectionRect = ensureDOMRect(entry.intersectionRect || getEmptyRect());
  this.isIntersecting = !!entry.intersectionRect;

  // Calculates the intersection ratio.
  var targetRect = this.boundingClientRect;
  var targetArea = targetRect.width * targetRect.height;
  var intersectionRect = this.intersectionRect;
  var intersectionArea = intersectionRect.width * intersectionRect.height;

  // Sets intersection ratio.
  if (targetArea) {
    // Round the intersection ratio to avoid floating point math issues:
    // https://github.com/w3c/IntersectionObserver/issues/324
    this.intersectionRatio = Number((intersectionArea / targetArea).toFixed(4));
  } else {
    // If area is zero and is intersecting, sets to 1, otherwise to 0
    this.intersectionRatio = this.isIntersecting ? 1 : 0;
  }
}


/**
 * Creates the global IntersectionObserver constructor.
 * https://w3c.github.io/IntersectionObserver/#intersection-observer-interface
 * @param {Function} callback The function to be invoked after intersection
 *     changes have queued. The function is not invoked if the queue has
 *     been emptied by calling the `takeRecords` method.
 * @param {Object=} opt_options Optional configuration options.
 * @constructor
 */
function IntersectionObserver(callback, opt_options) {

  var options = opt_options || {};

  if (typeof callback != 'function') {
    throw new Error('callback must be a function');
  }

  if (options.root && options.root.nodeType != 1) {
    throw new Error('root must be an Element');
  }

  // Binds and throttles `this._checkForIntersections`.
  this._checkForIntersections = throttle(
      this._checkForIntersections.bind(this), this.THROTTLE_TIMEOUT);

  // Private properties.
  this._callback = callback;
  this._observationTargets = [];
  this._queuedEntries = [];
  this._rootMarginValues = this._parseRootMargin(options.rootMargin);

  // Public properties.
  this.thresholds = this._initThresholds(options.threshold);
  this.root = options.root || null;
  this.rootMargin = this._rootMarginValues.map(function(margin) {
    return margin.value + margin.unit;
  }).join(' ');

  /** @private @const {!Array<!Document>} */
  this._monitoringDocuments = [];
  /** @private @const {!Array<function()>} */
  this._monitoringUnsubscribes = [];
}


/**
 * The minimum interval within which the document will be checked for
 * intersection changes.
 */
IntersectionObserver.prototype.THROTTLE_TIMEOUT = 100;


/**
 * The frequency in which the polyfill polls for intersection changes.
 * this can be updated on a per instance basis and must be set prior to
 * calling `observe` on the first target.
 */
IntersectionObserver.prototype.POLL_INTERVAL = null;

/**
 * Use a mutation observer on the root element
 * to detect intersection changes.
 */
IntersectionObserver.prototype.USE_MUTATION_OBSERVER = true;


/**
 * Sets up the polyfill in the cross-origin mode. The result is the
 * updater function that accepts two arguments: `boundingClientRect` and
 * `intersectionRect` - just as these fields would be available to the
 * parent via `IntersectionObserverEntry`. This function should be called
 * each time the iframe receives intersection information from the parent
 * window, e.g. via messaging.
 * @return {function(DOMRect|ClientRect, DOMRect|ClientRect)}
 */
IntersectionObserver._setupCrossOriginUpdater = function() {
  if (!crossOriginUpdater) {
    /**
     * @param {DOMRect|ClientRect} boundingClientRect
     * @param {DOMRect|ClientRect} intersectionRect
     */
    crossOriginUpdater = function(boundingClientRect, intersectionRect) {
      if (!boundingClientRect || !intersectionRect) {
        crossOriginRect = getEmptyRect();
      } else {
        crossOriginRect = convertFromParentRect(boundingClientRect, intersectionRect);
      }
      registry.forEach(function(observer) {
        observer._checkForIntersections();
      });
    };
  }
  return crossOriginUpdater;
};


/**
 * Resets the cross-origin mode.
 */
IntersectionObserver._resetCrossOriginUpdater = function() {
  crossOriginUpdater = null;
  crossOriginRect = null;
};


/**
 * Starts observing a target element for intersection changes based on
 * the thresholds values.
 * @param {Element} target The DOM element to observe.
 */
IntersectionObserver.prototype.observe = function(target) {
  var isTargetAlreadyObserved = this._observationTargets.some(function(item) {
    return item.element == target;
  });

  if (isTargetAlreadyObserved) {
    return;
  }

  if (!(target && target.nodeType == 1)) {
    throw new Error('target must be an Element');
  }

  this._registerInstance();
  this._observationTargets.push({element: target, entry: null});
  this._monitorIntersections(target.ownerDocument);
  this._checkForIntersections();
};


/**
 * Stops observing a target element for intersection changes.
 * @param {Element} target The DOM element to observe.
 */
IntersectionObserver.prototype.unobserve = function(target) {
  this._observationTargets =
      this._observationTargets.filter(function(item) {
        return item.element != target;
      });
  this._unmonitorIntersections(target.ownerDocument);
  if (this._observationTargets.length == 0) {
    this._unregisterInstance();
  }
};


/**
 * Stops observing all target elements for intersection changes.
 */
IntersectionObserver.prototype.disconnect = function() {
  this._observationTargets = [];
  this._unmonitorAllIntersections();
  this._unregisterInstance();
};


/**
 * Returns any queue entries that have not yet been reported to the
 * callback and clears the queue. This can be used in conjunction with the
 * callback to obtain the absolute most up-to-date intersection information.
 * @return {Array} The currently queued entries.
 */
IntersectionObserver.prototype.takeRecords = function() {
  var records = this._queuedEntries.slice();
  this._queuedEntries = [];
  return records;
};


/**
 * Accepts the threshold value from the user configuration object and
 * returns a sorted array of unique threshold values. If a value is not
 * between 0 and 1 and error is thrown.
 * @private
 * @param {Array|number=} opt_threshold An optional threshold value or
 *     a list of threshold values, defaulting to [0].
 * @return {Array} A sorted list of unique and valid threshold values.
 */
IntersectionObserver.prototype._initThresholds = function(opt_threshold) {
  var threshold = opt_threshold || [0];
  if (!Array.isArray(threshold)) threshold = [threshold];

  return threshold.sort().filter(function(t, i, a) {
    if (typeof t != 'number' || isNaN(t) || t < 0 || t > 1) {
      throw new Error('threshold must be a number between 0 and 1 inclusively');
    }
    return t !== a[i - 1];
  });
};


/**
 * Accepts the rootMargin value from the user configuration object
 * and returns an array of the four margin values as an object containing
 * the value and unit properties. If any of the values are not properly
 * formatted or use a unit other than px or %, and error is thrown.
 * @private
 * @param {string=} opt_rootMargin An optional rootMargin value,
 *     defaulting to '0px'.
 * @return {Array<Object>} An array of margin objects with the keys
 *     value and unit.
 */
IntersectionObserver.prototype._parseRootMargin = function(opt_rootMargin) {
  var marginString = opt_rootMargin || '0px';
  var margins = marginString.split(/\s+/).map(function(margin) {
    var parts = /^(-?\d*\.?\d+)(px|%)$/.exec(margin);
    if (!parts) {
      throw new Error('rootMargin must be specified in pixels or percent');
    }
    return {value: parseFloat(parts[1]), unit: parts[2]};
  });

  // Handles shorthand.
  margins[1] = margins[1] || margins[0];
  margins[2] = margins[2] || margins[0];
  margins[3] = margins[3] || margins[1];

  return margins;
};


/**
 * Starts polling for intersection changes if the polling is not already
 * happening, and if the page's visibility state is visible.
 * @param {!Document} doc
 * @private
 */
IntersectionObserver.prototype._monitorIntersections = function(doc) {
  var win = doc.defaultView;
  if (!win) {
    // Already destroyed.
    return;
  }
  if (this._monitoringDocuments.indexOf(doc) != -1) {
    // Already monitoring.
    return;
  }

  // Private state for monitoring.
  var callback = this._checkForIntersections;
  var monitoringInterval = null;
  var domObserver = null;

  // If a poll interval is set, use polling instead of listening to
  // resize and scroll events or DOM mutations.
  if (this.POLL_INTERVAL) {
    monitoringInterval = win.setInterval(callback, this.POLL_INTERVAL);
  } else {
    addEvent(win, 'resize', callback, true);
    addEvent(doc, 'scroll', callback, true);
    if (this.USE_MUTATION_OBSERVER && 'MutationObserver' in win) {
      domObserver = new win.MutationObserver(callback);
      domObserver.observe(doc, {
        attributes: true,
        childList: true,
        characterData: true,
        subtree: true
      });
    }
  }

  this._monitoringDocuments.push(doc);
  this._monitoringUnsubscribes.push(function() {
    // Get the window object again. When a friendly iframe is destroyed, it
    // will be null.
    var win = doc.defaultView;

    if (win) {
      if (monitoringInterval) {
        win.clearInterval(monitoringInterval);
      }
      removeEvent(win, 'resize', callback, true);
    }

    removeEvent(doc, 'scroll', callback, true);
    if (domObserver) {
      domObserver.disconnect();
    }
  });

  // Also monitor the parent.
  if (doc != (this.root && this.root.ownerDocument || document)) {
    var frame = getFrameElement(doc);
    if (frame) {
      this._monitorIntersections(frame.ownerDocument);
    }
  }
};


/**
 * Stops polling for intersection changes.
 * @param {!Document} doc
 * @private
 */
IntersectionObserver.prototype._unmonitorIntersections = function(doc) {
  var index = this._monitoringDocuments.indexOf(doc);
  if (index == -1) {
    return;
  }

  var rootDoc = (this.root && this.root.ownerDocument || document);

  // Check if any dependent targets are still remaining.
  var hasDependentTargets =
      this._observationTargets.some(function(item) {
        var itemDoc = item.element.ownerDocument;
        // Target is in this context.
        if (itemDoc == doc) {
          return true;
        }
        // Target is nested in this context.
        while (itemDoc && itemDoc != rootDoc) {
          var frame = getFrameElement(itemDoc);
          itemDoc = frame && frame.ownerDocument;
          if (itemDoc == doc) {
            return true;
          }
        }
        return false;
      });
  if (hasDependentTargets) {
    return;
  }

  // Unsubscribe.
  var unsubscribe = this._monitoringUnsubscribes[index];
  this._monitoringDocuments.splice(index, 1);
  this._monitoringUnsubscribes.splice(index, 1);
  unsubscribe();

  // Also unmonitor the parent.
  if (doc != rootDoc) {
    var frame = getFrameElement(doc);
    if (frame) {
      this._unmonitorIntersections(frame.ownerDocument);
    }
  }
};


/**
 * Stops polling for intersection changes.
 * @param {!Document} doc
 * @private
 */
IntersectionObserver.prototype._unmonitorAllIntersections = function() {
  var unsubscribes = this._monitoringUnsubscribes.slice(0);
  this._monitoringDocuments.length = 0;
  this._monitoringUnsubscribes.length = 0;
  for (var i = 0; i < unsubscribes.length; i++) {
    unsubscribes[i]();
  }
};


/**
 * Scans each observation target for intersection changes and adds them
 * to the internal entries queue. If new entries are found, it
 * schedules the callback to be invoked.
 * @private
 */
IntersectionObserver.prototype._checkForIntersections = function() {
  if (!this.root && crossOriginUpdater && !crossOriginRect) {
    // Cross origin monitoring, but no initial data available yet.
    return;
  }

  var rootIsInDom = this._rootIsInDom();
  var rootRect = rootIsInDom ? this._getRootRect() : getEmptyRect();

  this._observationTargets.forEach(function(item) {
    var target = item.element;
    var targetRect = getBoundingClientRect(target);
    var rootContainsTarget = this._rootContainsTarget(target);
    var oldEntry = item.entry;
    var intersectionRect = rootIsInDom && rootContainsTarget &&
        this._computeTargetAndRootIntersection(target, targetRect, rootRect);

    var newEntry = item.entry = new IntersectionObserverEntry({
      time: now(),
      target: target,
      boundingClientRect: targetRect,
      rootBounds: crossOriginUpdater && !this.root ? null : rootRect,
      intersectionRect: intersectionRect
    });

    if (!oldEntry) {
      this._queuedEntries.push(newEntry);
    } else if (rootIsInDom && rootContainsTarget) {
      // If the new entry intersection ratio has crossed any of the
      // thresholds, add a new entry.
      if (this._hasCrossedThreshold(oldEntry, newEntry)) {
        this._queuedEntries.push(newEntry);
      }
    } else {
      // If the root is not in the DOM or target is not contained within
      // root but the previous entry for this target had an intersection,
      // add a new record indicating removal.
      if (oldEntry && oldEntry.isIntersecting) {
        this._queuedEntries.push(newEntry);
      }
    }
  }, this);

  if (this._queuedEntries.length) {
    this._callback(this.takeRecords(), this);
  }
};


/**
 * Accepts a target and root rect computes the intersection between then
 * following the algorithm in the spec.
 * TODO(philipwalton): at this time clip-path is not considered.
 * https://w3c.github.io/IntersectionObserver/#calculate-intersection-rect-algo
 * @param {Element} target The target DOM element
 * @param {Object} targetRect The bounding rect of the target.
 * @param {Object} rootRect The bounding rect of the root after being
 *     expanded by the rootMargin value.
 * @return {?Object} The final intersection rect object or undefined if no
 *     intersection is found.
 * @private
 */
IntersectionObserver.prototype._computeTargetAndRootIntersection =
    function(target, targetRect, rootRect) {
  // If the element isn't displayed, an intersection can't happen.
  if (window.getComputedStyle(target).display == 'none') return;

  var intersectionRect = targetRect;
  var parent = getParentNode(target);
  var atRoot = false;

  while (!atRoot && parent) {
    var parentRect = null;
    var parentComputedStyle = parent.nodeType == 1 ?
        window.getComputedStyle(parent) : {};

    // If the parent isn't displayed, an intersection can't happen.
    if (parentComputedStyle.display == 'none') return null;

    if (parent == this.root || parent.nodeType == /* DOCUMENT */ 9) {
      atRoot = true;
      if (parent == this.root || parent == document) {
        if (crossOriginUpdater && !this.root) {
          if (!crossOriginRect ||
              crossOriginRect.width == 0 && crossOriginRect.height == 0) {
            // A 0-size cross-origin intersection means no-intersection.
            parent = null;
            parentRect = null;
            intersectionRect = null;
          } else {
            parentRect = crossOriginRect;
          }
        } else {
          parentRect = rootRect;
        }
      } else {
        // Check if there's a frame that can be navigated to.
        var frame = getParentNode(parent);
        var frameRect = frame && getBoundingClientRect(frame);
        var frameIntersect =
            frame &&
            this._computeTargetAndRootIntersection(frame, frameRect, rootRect);
        if (frameRect && frameIntersect) {
          parent = frame;
          parentRect = convertFromParentRect(frameRect, frameIntersect);
        } else {
          parent = null;
          intersectionRect = null;
        }
      }
    } else {
      // If the element has a non-visible overflow, and it's not the <body>
      // or <html> element, update the intersection rect.
      // Note: <body> and <html> cannot be clipped to a rect that's not also
      // the document rect, so no need to compute a new intersection.
      var doc = parent.ownerDocument;
      if (parent != doc.body &&
          parent != doc.documentElement &&
          parentComputedStyle.overflow != 'visible') {
        parentRect = getBoundingClientRect(parent);
      }
    }

    // If either of the above conditionals set a new parentRect,
    // calculate new intersection data.
    if (parentRect) {
      intersectionRect = computeRectIntersection(parentRect, intersectionRect);
    }
    if (!intersectionRect) break;
    parent = parent && getParentNode(parent);
  }
  return intersectionRect;
};


/**
 * Returns the root rect after being expanded by the rootMargin value.
 * @return {ClientRect} The expanded root rect.
 * @private
 */
IntersectionObserver.prototype._getRootRect = function() {
  var rootRect;
  if (this.root) {
    rootRect = getBoundingClientRect(this.root);
  } else {
    // Use <html>/<body> instead of window since scroll bars affect size.
    var html = document.documentElement;
    var body = document.body;
    rootRect = {
      top: 0,
      left: 0,
      right: html.clientWidth || body.clientWidth,
      width: html.clientWidth || body.clientWidth,
      bottom: html.clientHeight || body.clientHeight,
      height: html.clientHeight || body.clientHeight
    };
  }
  return this._expandRectByRootMargin(rootRect);
};


/**
 * Accepts a rect and expands it by the rootMargin value.
 * @param {DOMRect|ClientRect} rect The rect object to expand.
 * @return {ClientRect} The expanded rect.
 * @private
 */
IntersectionObserver.prototype._expandRectByRootMargin = function(rect) {
  var margins = this._rootMarginValues.map(function(margin, i) {
    return margin.unit == 'px' ? margin.value :
        margin.value * (i % 2 ? rect.width : rect.height) / 100;
  });
  var newRect = {
    top: rect.top - margins[0],
    right: rect.right + margins[1],
    bottom: rect.bottom + margins[2],
    left: rect.left - margins[3]
  };
  newRect.width = newRect.right - newRect.left;
  newRect.height = newRect.bottom - newRect.top;

  return newRect;
};


/**
 * Accepts an old and new entry and returns true if at least one of the
 * threshold values has been crossed.
 * @param {?IntersectionObserverEntry} oldEntry The previous entry for a
 *    particular target element or null if no previous entry exists.
 * @param {IntersectionObserverEntry} newEntry The current entry for a
 *    particular target element.
 * @return {boolean} Returns true if a any threshold has been crossed.
 * @private
 */
IntersectionObserver.prototype._hasCrossedThreshold =
    function(oldEntry, newEntry) {

  // To make comparing easier, an entry that has a ratio of 0
  // but does not actually intersect is given a value of -1
  var oldRatio = oldEntry && oldEntry.isIntersecting ?
      oldEntry.intersectionRatio || 0 : -1;
  var newRatio = newEntry.isIntersecting ?
      newEntry.intersectionRatio || 0 : -1;

  // Ignore unchanged ratios
  if (oldRatio === newRatio) return;

  for (var i = 0; i < this.thresholds.length; i++) {
    var threshold = this.thresholds[i];

    // Return true if an entry matches a threshold or if the new ratio
    // and the old ratio are on the opposite sides of a threshold.
    if (threshold == oldRatio || threshold == newRatio ||
        threshold < oldRatio !== threshold < newRatio) {
      return true;
    }
  }
};


/**
 * Returns whether or not the root element is an element and is in the DOM.
 * @return {boolean} True if the root element is an element and is in the DOM.
 * @private
 */
IntersectionObserver.prototype._rootIsInDom = function() {
  return !this.root || containsDeep(document, this.root);
};


/**
 * Returns whether or not the target element is a child of root.
 * @param {Element} target The target element to check.
 * @return {boolean} True if the target element is a child of root.
 * @private
 */
IntersectionObserver.prototype._rootContainsTarget = function(target) {
  return containsDeep(this.root || document, target) &&
    (!this.root || this.root.ownerDocument == target.ownerDocument);
};


/**
 * Adds the instance to the global IntersectionObserver registry if it isn't
 * already present.
 * @private
 */
IntersectionObserver.prototype._registerInstance = function() {
  if (registry.indexOf(this) < 0) {
    registry.push(this);
  }
};


/**
 * Removes the instance from the global IntersectionObserver registry.
 * @private
 */
IntersectionObserver.prototype._unregisterInstance = function() {
  var index = registry.indexOf(this);
  if (index != -1) registry.splice(index, 1);
};


/**
 * Returns the result of the performance.now() method or null in browsers
 * that don't support the API.
 * @return {number} The elapsed time since the page was requested.
 */
function now() {
  return window.performance && performance.now && performance.now();
}


/**
 * Throttles a function and delays its execution, so it's only called at most
 * once within a given time period.
 * @param {Function} fn The function to throttle.
 * @param {number} timeout The amount of time that must pass before the
 *     function can be called again.
 * @return {Function} The throttled function.
 */
function throttle(fn, timeout) {
  var timer = null;
  return function () {
    if (!timer) {
      timer = setTimeout(function() {
        fn();
        timer = null;
      }, timeout);
    }
  };
}


/**
 * Adds an event handler to a DOM node ensuring cross-browser compatibility.
 * @param {Node} node The DOM node to add the event handler to.
 * @param {string} event The event name.
 * @param {Function} fn The event handler to add.
 * @param {boolean} opt_useCapture Optionally adds the even to the capture
 *     phase. Note: this only works in modern browsers.
 */
function addEvent(node, event, fn, opt_useCapture) {
  if (typeof node.addEventListener == 'function') {
    node.addEventListener(event, fn, opt_useCapture || false);
  }
  else if (typeof node.attachEvent == 'function') {
    node.attachEvent('on' + event, fn);
  }
}


/**
 * Removes a previously added event handler from a DOM node.
 * @param {Node} node The DOM node to remove the event handler from.
 * @param {string} event The event name.
 * @param {Function} fn The event handler to remove.
 * @param {boolean} opt_useCapture If the event handler was added with this
 *     flag set to true, it should be set to true here in order to remove it.
 */
function removeEvent(node, event, fn, opt_useCapture) {
  if (typeof node.removeEventListener == 'function') {
    node.removeEventListener(event, fn, opt_useCapture || false);
  }
  else if (typeof node.detatchEvent == 'function') {
    node.detatchEvent('on' + event, fn);
  }
}


/**
 * Returns the intersection between two rect objects.
 * @param {Object} rect1 The first rect.
 * @param {Object} rect2 The second rect.
 * @return {?Object|?ClientRect} The intersection rect or undefined if no
 *     intersection is found.
 */
function computeRectIntersection(rect1, rect2) {
  var top = Math.max(rect1.top, rect2.top);
  var bottom = Math.min(rect1.bottom, rect2.bottom);
  var left = Math.max(rect1.left, rect2.left);
  var right = Math.min(rect1.right, rect2.right);
  var width = right - left;
  var height = bottom - top;

  return (width >= 0 && height >= 0) && {
    top: top,
    bottom: bottom,
    left: left,
    right: right,
    width: width,
    height: height
  } || null;
}


/**
 * Shims the native getBoundingClientRect for compatibility with older IE.
 * @param {Element} el The element whose bounding rect to get.
 * @return {DOMRect|ClientRect} The (possibly shimmed) rect of the element.
 */
function getBoundingClientRect(el) {
  var rect;

  try {
    rect = el.getBoundingClientRect();
  } catch (err) {
    // Ignore Windows 7 IE11 "Unspecified error"
    // https://github.com/w3c/IntersectionObserver/pull/205
  }

  if (!rect) return getEmptyRect();

  // Older IE
  if (!(rect.width && rect.height)) {
    rect = {
      top: rect.top,
      right: rect.right,
      bottom: rect.bottom,
      left: rect.left,
      width: rect.right - rect.left,
      height: rect.bottom - rect.top
    };
  }
  return rect;
}


/**
 * Returns an empty rect object. An empty rect is returned when an element
 * is not in the DOM.
 * @return {ClientRect} The empty rect.
 */
function getEmptyRect() {
  return {
    top: 0,
    bottom: 0,
    left: 0,
    right: 0,
    width: 0,
    height: 0
  };
}


/**
 * Ensure that the result has all of the necessary fields of the DOMRect.
 * Specifically this ensures that `x` and `y` fields are set.
 *
 * @param {?DOMRect|?ClientRect} rect
 * @return {?DOMRect}
 */
function ensureDOMRect(rect) {
  // A `DOMRect` object has `x` and `y` fields.
  if (!rect || 'x' in rect) {
    return rect;
  }
  // A IE's `ClientRect` type does not have `x` and `y`. The same is the case
  // for internally calculated Rect objects. For the purposes of
  // `IntersectionObserver`, it's sufficient to simply mirror `left` and `top`
  // for these fields.
  return {
    top: rect.top,
    y: rect.top,
    bottom: rect.bottom,
    left: rect.left,
    x: rect.left,
    right: rect.right,
    width: rect.width,
    height: rect.height
  };
}


/**
 * Inverts the intersection and bounding rect from the parent (frame) BCR to
 * the local BCR space.
 * @param {DOMRect|ClientRect} parentBoundingRect The parent's bound client rect.
 * @param {DOMRect|ClientRect} parentIntersectionRect The parent's own intersection rect.
 * @return {ClientRect} The local root bounding rect for the parent's children.
 */
function convertFromParentRect(parentBoundingRect, parentIntersectionRect) {
  var top = parentIntersectionRect.top - parentBoundingRect.top;
  var left = parentIntersectionRect.left - parentBoundingRect.left;
  return {
    top: top,
    left: left,
    height: parentIntersectionRect.height,
    width: parentIntersectionRect.width,
    bottom: top + parentIntersectionRect.height,
    right: left + parentIntersectionRect.width
  };
}


/**
 * Checks to see if a parent element contains a child element (including inside
 * shadow DOM).
 * @param {Node} parent The parent element.
 * @param {Node} child The child element.
 * @return {boolean} True if the parent node contains the child node.
 */
function containsDeep(parent, child) {
  var node = child;
  while (node) {
    if (node == parent) return true;

    node = getParentNode(node);
  }
  return false;
}


/**
 * Gets the parent node of an element or its host element if the parent node
 * is a shadow root.
 * @param {Node} node The node whose parent to get.
 * @return {Node|null} The parent node or null if no parent exists.
 */
function getParentNode(node) {
  var parent = node.parentNode;

  if (node.nodeType == /* DOCUMENT */ 9 && node != document) {
    // If this node is a document node, look for the embedding frame.
    return getFrameElement(node);
  }

  if (parent && parent.nodeType == 11 && parent.host) {
    // If the parent is a shadow root, return the host element.
    return parent.host;
  }

  if (parent && parent.assignedSlot) {
    // If the parent is distributed in a <slot>, return the parent of a slot.
    return parent.assignedSlot.parentNode;
  }

  return parent;
}


/**
 * Returns the embedding frame element, if any.
 * @param {!Document} doc
 * @return {!Element}
 */
function getFrameElement(doc) {
  try {
    return doc.defaultView && doc.defaultView.frameElement || null;
  } catch (e) {
    // Ignore the error.
    return null;
  }
}


// Exposes the constructors globally.
window.IntersectionObserver = IntersectionObserver;
window.IntersectionObserverEntry = IntersectionObserverEntry;

}());

},{}],"vL5c":[function(require,module,exports) {
var define;
var global = arguments[3];
(function (global, factory) {
	typeof exports === 'object' && typeof module !== 'undefined' ? module.exports = factory() :
	typeof define === 'function' && define.amd ? define(factory) :
	(global.scrollama = factory());
}(this, (function () { 'use strict';

// DOM helper functions

// public
function selectAll(selector, parent) {
  if ( parent === void 0 ) parent = document;

  if (typeof selector === 'string') {
    return Array.from(parent.querySelectorAll(selector));
  } else if (selector instanceof Element) {
    return [selector];
  } else if (selector instanceof NodeList) {
    return Array.from(selector);
  } else if (selector instanceof Array) {
    return selector;
  }
  return [];
}

function getOffsetId(id) {
  return ("scrollama__debug-offset--" + id);
}

// SETUP
function setupOffset(ref) {
  var id = ref.id;
  var offsetVal = ref.offsetVal;
  var stepClass = ref.stepClass;

  var el = document.createElement("div");
  el.id = getOffsetId(id);
  el.className = "scrollama__debug-offset";
  el.style.position = "fixed";
  el.style.left = "0";
  el.style.width = "100%";
  el.style.height = "0";
  el.style.borderTop = "2px dashed black";
  el.style.zIndex = "9999";

  var p = document.createElement("p");
  p.innerHTML = "\"." + stepClass + "\" trigger: <span>" + offsetVal + "</span>";
  p.style.fontSize = "12px";
  p.style.fontFamily = "monospace";
  p.style.color = "black";
  p.style.margin = "0";
  p.style.padding = "6px";
  el.appendChild(p);
  document.body.appendChild(el);
}

function setup(ref) {
  var id = ref.id;
  var offsetVal = ref.offsetVal;
  var stepEl = ref.stepEl;

  var stepClass = stepEl[0].className;
  setupOffset({ id: id, offsetVal: offsetVal, stepClass: stepClass });
}

// UPDATE
function update(ref) {
  var id = ref.id;
  var offsetMargin = ref.offsetMargin;
  var offsetVal = ref.offsetVal;
  var format = ref.format;

  var post = format === "pixels" ? "px" : "";
  var idVal = getOffsetId(id);
  var el = document.getElementById(idVal);
  el.style.top = offsetMargin + "px";
  el.querySelector("span").innerText = "" + offsetVal + post;
}

function notifyStep(ref) {
  var id = ref.id;
  var index = ref.index;
  var state = ref.state;

  var prefix = "scrollama__debug-step--" + id + "-" + index;
  var elA = document.getElementById((prefix + "_above"));
  var elB = document.getElementById((prefix + "_below"));
  var display = state === "enter" ? "block" : "none";

  if (elA) { elA.style.display = display; }
  if (elB) { elB.style.display = display; }
}

function scrollama() {
  var OBSERVER_NAMES = [
    "stepAbove",
    "stepBelow",
    "stepProgress",
    "viewportAbove",
    "viewportBelow"
  ];

  var cb = {};
  var io = {};

  var id = null;
  var stepEl = [];
  var stepOffsetHeight = [];
  var stepOffsetTop = [];
  var stepStates = [];

  var offsetVal = 0;
  var offsetMargin = 0;
  var viewH = 0;
  var pageH = 0;
  var previousYOffset = 0;
  var progressThreshold = 0;

  var isReady = false;
  var isEnabled = false;
  var isDebug = false;

  var progressMode = false;
  var preserveOrder = false;
  var triggerOnce = false;

  var direction = "down";
  var format = "percent";

  var exclude = [];

  /* HELPERS */
  function err(msg) {
    console.error(("scrollama error: " + msg));
  }

  function reset() {
    cb = {
      stepEnter: function () {},
      stepExit: function () {},
      stepProgress: function () {}
    };
    io = {};
  }

  function generateInstanceID() {
    var a = "abcdefghijklmnopqrstuv";
    var l = a.length;
    var t = Date.now();
    var r = [0, 0, 0].map(function (d) { return a[Math.floor(Math.random() * l)]; }).join("");
    return ("" + r + t);
  }

  function getOffsetTop(el) {
    var ref = el.getBoundingClientRect();
    var top = ref.top;
    var scrollTop = window.pageYOffset;
    var clientTop = document.body.clientTop || 0;
    return top + scrollTop - clientTop;
  }

  function getPageHeight() {
    var body = document.body;
    var html = document.documentElement;

    return Math.max(
      body.scrollHeight,
      body.offsetHeight,
      html.clientHeight,
      html.scrollHeight,
      html.offsetHeight
    );
  }

  function getIndex(element) {
    return +element.getAttribute("data-scrollama-index");
  }

  function updateDirection() {
    if (window.pageYOffset > previousYOffset) { direction = "down"; }
    else if (window.pageYOffset < previousYOffset) { direction = "up"; }
    previousYOffset = window.pageYOffset;
  }

  function disconnectObserver(name) {
    if (io[name]) { io[name].forEach(function (d) { return d.disconnect(); }); }
  }

  function handleResize() {
    viewH = window.innerHeight;
    pageH = getPageHeight();

    var mult = format === "pixels" ? 1 : viewH;
    offsetMargin = offsetVal * mult;

    if (isReady) {
      stepOffsetHeight = stepEl.map(function (el) { return el.getBoundingClientRect().height; });
      stepOffsetTop = stepEl.map(getOffsetTop);
      if (isEnabled) { updateIO(); }
    }

    if (isDebug) { update({ id: id, offsetMargin: offsetMargin, offsetVal: offsetVal, format: format }); }
  }

  function handleEnable(enable) {
    if (enable && !isEnabled) {
      // enable a disabled scroller
      if (isReady) {
        // enable a ready scroller
        updateIO();
      } else {
        // can't enable an unready scroller
        err("scrollama error: enable() called before scroller was ready");
        isEnabled = false;
        return; // all is not well, don't set the requested state
      }
    }
    if (!enable && isEnabled) {
      // disable an enabled scroller
      OBSERVER_NAMES.forEach(disconnectObserver);
    }
    isEnabled = enable; // all is well, set requested state
  }

  function createThreshold(height) {
    var count = Math.ceil(height / progressThreshold);
    var t = [];
    var ratio = 1 / count;
    for (var i = 0; i < count; i += 1) {
      t.push(i * ratio);
    }
    return t;
  }

  /* NOTIFY CALLBACKS */
  function notifyStepProgress(element, progress) {
    var index = getIndex(element);
    if (progress !== undefined) { stepStates[index].progress = progress; }
    var resp = { element: element, index: index, progress: stepStates[index].progress };

    if (stepStates[index].state === "enter") { cb.stepProgress(resp); }
  }

  function notifyOthers(index, location) {
    if (location === "above") {
      // check if steps above/below were skipped and should be notified first
      for (var i = 0; i < index; i += 1) {
        var ss = stepStates[i];
        if (ss.state !== "enter" && ss.direction !== "down") {
          notifyStepEnter(stepEl[i], "down", false);
          notifyStepExit(stepEl[i], "down");
        } else if (ss.state === "enter") { notifyStepExit(stepEl[i], "down"); }
        // else if (ss.direction === 'up') {
        //   notifyStepEnter(stepEl[i], 'down', false);
        //   notifyStepExit(stepEl[i], 'down');
        // }
      }
    } else if (location === "below") {
      for (var i$1 = stepStates.length - 1; i$1 > index; i$1 -= 1) {
        var ss$1 = stepStates[i$1];
        if (ss$1.state === "enter") {
          notifyStepExit(stepEl[i$1], "up");
        }
        if (ss$1.direction === "down") {
          notifyStepEnter(stepEl[i$1], "up", false);
          notifyStepExit(stepEl[i$1], "up");
        }
      }
    }
  }

  function notifyStepEnter(element, dir, check) {
    if ( check === void 0 ) check = true;

    var index = getIndex(element);
    var resp = { element: element, index: index, direction: dir };

    // store most recent trigger
    stepStates[index].direction = dir;
    stepStates[index].state = "enter";
    if (preserveOrder && check && dir === "down") { notifyOthers(index, "above"); }

    if (preserveOrder && check && dir === "up") { notifyOthers(index, "below"); }

    if (cb.stepEnter && !exclude[index]) {
      cb.stepEnter(resp, stepStates);
      if (isDebug) { notifyStep({ id: id, index: index, state: "enter" }); }
      if (triggerOnce) { exclude[index] = true; }
    }

    if (progressMode) { notifyStepProgress(element); }
  }

  function notifyStepExit(element, dir) {
    var index = getIndex(element);
    var resp = { element: element, index: index, direction: dir };

    if (progressMode) {
      if (dir === "down" && stepStates[index].progress < 1)
        { notifyStepProgress(element, 1); }
      else if (dir === "up" && stepStates[index].progress > 0)
        { notifyStepProgress(element, 0); }
    }

    // store most recent trigger
    stepStates[index].direction = dir;
    stepStates[index].state = "exit";

    cb.stepExit(resp, stepStates);
    if (isDebug) { notifyStep({ id: id, index: index, state: "exit" }); }
  }

  /* OBSERVER - INTERSECT HANDLING */
  // this is good for entering while scrolling down + leaving while scrolling up
  function intersectStepAbove(ref) {
    var entry = ref[0];

    updateDirection();
    var isIntersecting = entry.isIntersecting;
    var boundingClientRect = entry.boundingClientRect;
    var target = entry.target;

    // bottom = bottom edge of element from top of viewport
    // bottomAdjusted = bottom edge of element from trigger
    var top = boundingClientRect.top;
    var bottom = boundingClientRect.bottom;
    var topAdjusted = top - offsetMargin;
    var bottomAdjusted = bottom - offsetMargin;
    var index = getIndex(target);
    var ss = stepStates[index];

    // entering above is only when topAdjusted is negative
    // and bottomAdjusted is positive
    if (
      isIntersecting &&
      topAdjusted <= 0 &&
      bottomAdjusted >= 0 &&
      direction === "down" &&
      ss.state !== "enter"
    )
      { notifyStepEnter(target, direction); }

    // exiting from above is when topAdjusted is positive and not intersecting
    if (
      !isIntersecting &&
      topAdjusted > 0 &&
      direction === "up" &&
      ss.state === "enter"
    )
      { notifyStepExit(target, direction); }
  }

  // this is good for entering while scrolling up + leaving while scrolling down
  function intersectStepBelow(ref) {
    var entry = ref[0];

    updateDirection();
    var isIntersecting = entry.isIntersecting;
    var boundingClientRect = entry.boundingClientRect;
    var target = entry.target;

    // bottom = bottom edge of element from top of viewport
    // bottomAdjusted = bottom edge of element from trigger
    var top = boundingClientRect.top;
    var bottom = boundingClientRect.bottom;
    var topAdjusted = top - offsetMargin;
    var bottomAdjusted = bottom - offsetMargin;
    var index = getIndex(target);
    var ss = stepStates[index];

    // entering below is only when bottomAdjusted is positive
    // and topAdjusted is negative
    if (
      isIntersecting &&
      topAdjusted <= 0 &&
      bottomAdjusted >= 0 &&
      direction === "up" &&
      ss.state !== "enter"
    )
      { notifyStepEnter(target, direction); }

    // exiting from above is when bottomAdjusted is negative and not intersecting
    if (
      !isIntersecting &&
      bottomAdjusted < 0 &&
      direction === "down" &&
      ss.state === "enter"
    )
      { notifyStepExit(target, direction); }
  }

  /*
	if there is a scroll event where a step never intersects (therefore
	skipping an enter/exit trigger), use this fallback to detect if it is
	in view
	*/
  function intersectViewportAbove(ref) {
    var entry = ref[0];

    updateDirection();
    var isIntersecting = entry.isIntersecting;
    var target = entry.target;
    var index = getIndex(target);
    var ss = stepStates[index];

    if (
      isIntersecting &&
      direction === "down" &&
      ss.direction !== "down" &&
      ss.state !== "enter"
    ) {
      notifyStepEnter(target, "down");
      notifyStepExit(target, "down");
    }
  }

  function intersectViewportBelow(ref) {
    var entry = ref[0];

    updateDirection();
    var isIntersecting = entry.isIntersecting;
    var target = entry.target;
    var index = getIndex(target);
    var ss = stepStates[index];
    if (
      isIntersecting &&
      direction === "up" &&
      ss.direction === "down" &&
      ss.state !== "enter"
    ) {
      notifyStepEnter(target, "up");
      notifyStepExit(target, "up");
    }
  }

  function intersectStepProgress(ref) {
    var entry = ref[0];

    updateDirection();
    var isIntersecting = entry.isIntersecting;
    var intersectionRatio = entry.intersectionRatio;
    var boundingClientRect = entry.boundingClientRect;
    var target = entry.target;
    var bottom = boundingClientRect.bottom;
    var bottomAdjusted = bottom - offsetMargin;
    if (isIntersecting && bottomAdjusted >= 0) {
      notifyStepProgress(target, +intersectionRatio);
    }
  }

  /*  OBSERVER - CREATION */
  // jump into viewport
  function updateViewportAboveIO() {
    io.viewportAbove = stepEl.map(function (el, i) {
      var marginTop = pageH - stepOffsetTop[i];
      var marginBottom = offsetMargin - viewH - stepOffsetHeight[i];
      var rootMargin = marginTop + "px 0px " + marginBottom + "px 0px";
      var options = { rootMargin: rootMargin };
      // console.log(options);
      var obs = new IntersectionObserver(intersectViewportAbove, options);
      obs.observe(el);
      return obs;
    });
  }

  function updateViewportBelowIO() {
    io.viewportBelow = stepEl.map(function (el, i) {
      var marginTop = -offsetMargin - stepOffsetHeight[i];
      var marginBottom = offsetMargin - viewH + stepOffsetHeight[i] + pageH;
      var rootMargin = marginTop + "px 0px " + marginBottom + "px 0px";
      var options = { rootMargin: rootMargin };
      // console.log(options);
      var obs = new IntersectionObserver(intersectViewportBelow, options);
      obs.observe(el);
      return obs;
    });
  }

  // look above for intersection
  function updateStepAboveIO() {
    io.stepAbove = stepEl.map(function (el, i) {
      var marginTop = -offsetMargin + stepOffsetHeight[i];
      var marginBottom = offsetMargin - viewH;
      var rootMargin = marginTop + "px 0px " + marginBottom + "px 0px";
      var options = { rootMargin: rootMargin };
      // console.log(options);
      var obs = new IntersectionObserver(intersectStepAbove, options);
      obs.observe(el);
      return obs;
    });
  }

  // look below for intersection
  function updateStepBelowIO() {
    io.stepBelow = stepEl.map(function (el, i) {
      var marginTop = -offsetMargin;
      var marginBottom = offsetMargin - viewH + stepOffsetHeight[i];
      var rootMargin = marginTop + "px 0px " + marginBottom + "px 0px";
      var options = { rootMargin: rootMargin };
      // console.log(options);
      var obs = new IntersectionObserver(intersectStepBelow, options);
      obs.observe(el);
      return obs;
    });
  }

  // progress progress tracker
  function updateStepProgressIO() {
    io.stepProgress = stepEl.map(function (el, i) {
      var marginTop = stepOffsetHeight[i] - offsetMargin;
      var marginBottom = -viewH + offsetMargin;
      var rootMargin = marginTop + "px 0px " + marginBottom + "px 0px";
      var threshold = createThreshold(stepOffsetHeight[i]);
      var options = { rootMargin: rootMargin, threshold: threshold };
      // console.log(options);
      var obs = new IntersectionObserver(intersectStepProgress, options);
      obs.observe(el);
      return obs;
    });
  }

  function updateIO() {
    OBSERVER_NAMES.forEach(disconnectObserver);

    updateViewportAboveIO();
    updateViewportBelowIO();
    updateStepAboveIO();
    updateStepBelowIO();

    if (progressMode) { updateStepProgressIO(); }
  }

  /* SETUP FUNCTIONS */

  function indexSteps() {
    stepEl.forEach(function (el, i) { return el.setAttribute("data-scrollama-index", i); });
  }

  function setupStates() {
    stepStates = stepEl.map(function () { return ({
      direction: null,
      state: null,
      progress: 0
    }); });
  }

  function addDebug() {
    if (isDebug) { setup({ id: id, stepEl: stepEl, offsetVal: offsetVal }); }
  }

  function isYScrollable(element) {
    var style = window.getComputedStyle(element);
    return (
      (style.overflowY === "scroll" || style.overflowY === "auto") &&
      element.scrollHeight > element.clientHeight
    );
  }

  // recursively search the DOM for a parent container with overflowY: scroll and fixed height
  // ends at document
  function anyScrollableParent(element) {
    if (element && element.nodeType === 1) {
      // check dom elements only, stop at document
      // if a scrollable element is found return the element
      // if not continue to next parent
      return isYScrollable(element)
        ? element
        : anyScrollableParent(element.parentNode);
    }
    return false; // didn't find a scrollable parent
  }

  var S = {};

  S.setup = function (ref) {
    var step = ref.step;
    var offset = ref.offset; if ( offset === void 0 ) offset = 0.5;
    var progress = ref.progress; if ( progress === void 0 ) progress = false;
    var threshold = ref.threshold; if ( threshold === void 0 ) threshold = 4;
    var debug = ref.debug; if ( debug === void 0 ) debug = false;
    var order = ref.order; if ( order === void 0 ) order = true;
    var once = ref.once; if ( once === void 0 ) once = false;

    reset();
    // create id unique to this scrollama instance
    id = generateInstanceID();

    stepEl = selectAll(step);

    if (!stepEl.length) {
      err("no step elements");
      return S;
    }

    // ensure that no step has a scrollable parent element in the dom tree
    // check current step for scrollable parent
    // assume no scrollable parents to start
    var scrollableParent = stepEl.reduce(
      function (foundScrollable, s) { return foundScrollable || anyScrollableParent(s.parentNode); },
      false
    );
    if (scrollableParent) {
      console.error(
        "scrollama error: step elements cannot be children of a scrollable element. Remove any css on the parent element with overflow: scroll; or overflow: auto; on elements with fixed height.",
        scrollableParent
      );
    }

    // options
    isDebug = debug;
    progressMode = progress;
    preserveOrder = order;
    triggerOnce = once;

    S.offsetTrigger(offset);
    progressThreshold = Math.max(1, +threshold);

    isReady = true;

    // customize
    addDebug();
    indexSteps();
    setupStates();
    handleResize();
    S.enable();
    return S;
  };

  S.resize = function () {
    handleResize();
    return S;
  };

  S.enable = function () {
    handleEnable(true);
    return S;
  };

  S.disable = function () {
    handleEnable(false);
    return S;
  };

  S.destroy = function () {
    handleEnable(false);
    reset();
  };

  S.offsetTrigger = function (x) {
    if (x === null) { return offsetVal; }

    if (typeof x === "number") {
      format = "percent";
      if (x > 1) { err("offset value is greater than 1. Fallback to 1."); }
      if (x < 0) { err("offset value is lower than 0. Fallback to 0."); }
      offsetVal = Math.min(Math.max(0, x), 1);
    } else if (typeof x === "string" && x.indexOf("px") > 0) {
      var v = +x.replace("px", "");
      if (!isNaN(v)) {
        format = "pixels";
        offsetVal = v;
      } else {
        err("offset value must be in 'px' format. Fallback to 0.5.");
        offsetVal = 0.5;
      }
    } else {
      err("offset value does not include 'px'. Fallback to 0.5.");
      offsetVal = 0.5;
    }
    return S;
  };

  S.onStepEnter = function (f) {
    if (typeof f === "function") { cb.stepEnter = f; }
    else { err("onStepEnter requires a function"); }
    return S;
  };

  S.onStepExit = function (f) {
    if (typeof f === "function") { cb.stepExit = f; }
    else { err("onStepExit requires a function"); }
    return S;
  };

  S.onStepProgress = function (f) {
    if (typeof f === "function") { cb.stepProgress = f; }
    else { err("onStepProgress requires a function"); }
    return S;
  };

  return S;
}

return scrollama;

})));

},{}],"K8rx":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

require("intersection-observer");

var _scrollama = _interopRequireDefault(require("scrollama"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(source, true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(source).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

// candidate data
var data2020 = []; // DOM elements

var scroller = (0, _scrollama.default)();
var $container = d3.select('#scroll');
var $graphic = $container.select('.scroll__graphic');
var $gridDiv = $graphic.selectAll('.intro__grid');
var $text = $container.select('.scroll__text');
var $step = $text.selectAll('.step');
var $step0 = d3.select('#step-0');
var $introNameSpan = d3.selectAll('.intro-hover');
var $introSVG = d3.selectAll('.intro__svg'); // SCROLLAMA
// setup

function scrollSetup() {
  scroller.setup({
    container: '#scroll',
    // our outermost scrollytelling element
    graphic: '.scroll__graphic',
    // the graphic
    text: '.scroll__text',
    // the step container
    step: '.scroll__text .step',
    // the step elements
    offset: 0.75,
    // set the trigger to be 1/2 way down screen
    debug: false // display the trigger offset for testing

  }).onStepEnter(handleStepEnter);
} // resize


function handleResize() {
  loadGrid(); // 1. update height of step elements for breathing room between steps

  var stepHeight = Math.floor(window.innerHeight * 0.75);
  $step.style('height', stepHeight + 'px');
  $step0.style('margin-top', "-".concat(stepHeight, "px")); // 2. update height of graphic element

  var bodyWidth = d3.select('body').node().offsetWidth;
  $graphic.style('height', window.innerHeight + 'px'); // 3. tell scrollama to update new element dimensions

  scroller.resize();
} // step enter


function handleStepEnter(response) {
  $step.classed('is-active', function (d, i) {
    return i === response.index;
  });
  renderStep(response.index);
} // render step


function renderStep(index) {
  var $campaignLogos = d3.selectAll('.logoDiv');
  var $RWB_N = d3.selectAll('.RWB-N');
  var $RWB_Y = d3.selectAll('.RWB-Y');

  if (index === 0) {
    $text.style('pointer-events', 'none');
    $introSVG.transition().duration(500).ease(d3.easeLinear).style('opacity', 1);
    $campaignLogos.transition().duration(500).ease(d3.easeLinear).style('opacity', 0.125).style('filter', 'grayscale(100%)');
  }

  if (index === 1) {
    $text.style('pointer-events', 'auto');
    $introSVG.transition().duration(500).ease(d3.easeLinear).style('opacity', 0);
    $campaignLogos.transition().duration(1500).delay(function (d, i) {
      return i * 50;
    }).ease(d3.easeLinear).style('opacity', 1).style('filter', 'none');
    d3.selectAll('.logoDiv-bennet, .logoDiv-bullock, .logoDiv-ryan').classed('is-intext', false);
  }

  if (index === 2) {
    $RWB_N.transition().duration(200).ease(d3.easeLinear).style('opacity', 0.2).style('filter', 'grayscale(100%)');
    $RWB_Y.transition().duration(200).ease(d3.easeLinear).style('opacity', 1).style('filter', 'none');
    d3.selectAll('.logoDiv-biden, .logoDiv-trump').classed('is-intext', false);
    d3.selectAll('.logoDiv-bennet, .logoDiv-bullock, .logoDiv-ryan').classed('is-intext', true);
  }

  if (index === 3) {
    $RWB_N.transition().duration(500).ease(d3.easeLinear).style('opacity', 0.2).style('filter', 'grayscale(100%)');
    $RWB_Y.transition().duration(500).ease(d3.easeLinear).style('opacity', 1).style('filter', 'none');
    d3.selectAll('.logoDiv-biden, .logoDiv-trump').classed('is-intext', true);
    d3.selectAll('.logoDiv-bennet, .logoDiv-bullock, .logoDiv-ryan').classed('is-intext', false);
  }

  if (index === 4) {
    $RWB_N.transition().duration(500).ease(d3.easeLinear).style('opacity', 1).style('filter', 'none');
    $RWB_Y.transition().duration(500).ease(d3.easeLinear).style('opacity', 0.2).style('filter', 'grayscale(100%)');
    d3.selectAll('.logoDiv-biden, .logoDiv-trump').classed('is-intext', false);
    d3.selectAll('.logoDiv-harris, .logoDiv-orourke, .logoDiv-warren').classed('is-intext', false);
  }

  if (index === 5) {
    $RWB_N.transition().duration(500).ease(d3.easeLinear).style('opacity', 1).style('filter', 'none');
    $RWB_Y.transition().duration(500).ease(d3.easeLinear).style('opacity', 0.2).style('filter', 'grayscale(100%)');
    d3.selectAll('.logoDiv-harris, .logoDiv-orourke, .logoDiv-warren').classed('is-intext', true);
  }

  if (index === 6) {
    $campaignLogos.transition().duration(500).ease(d3.easeLinear).style('opacity', 1).style('filter', 'none');
    d3.selectAll('.logoDiv-harris, .logoDiv-orourke, .logoDiv-warren').classed('is-intext', false);
  }
} // GRID
// load in images


function loadGrid() {
  var containerW = $graphic.node().offsetWidth;
  var containerH = $graphic.node().offsetHeight;
  var containerArea = containerW * containerH;
  var numLogos = data2020.length;
  var areaPerLogo = containerArea / numLogos;
  var logoscale = 0.95;
  var logoH = Math.floor(Math.sqrt(areaPerLogo / 1.777) * logoscale);
  var logoW = Math.floor(logoH * 1.777 * logoscale);
  $gridDiv.selectAll('.logoDiv').data(data2020).enter().append('div').attr('class', function (d) {
    return "logoDiv logoDiv-".concat(d.nameID, " RWB-").concat(d.RWB);
  }).append('img').attr('src', function (d) {
    return "assets/images/2020-".concat(d.nameID, ".jpg");
  }).attr('alt', function (d) {
    return "".concat(d.name, " campaign logo");
  }).style('width', "".concat(logoW, "px")).style('height', "".concat(logoH, "px")); //.style('filter', 'grayscale(100%)')
} // fade in grid


function fadeInGrid() {
  var $campaignLogos = d3.selectAll('.logoDiv');
  $campaignLogos.transition().duration(1500).delay(function (d, i) {
    return i * 100;
  }).ease(d3.easeLinear).style('opacity', 0.125);
} // title animations


function bounceArrow() {
  var arrow = d3.selectAll('#lines polygon');
  arrow.transition().duration(5000).ease(d3.easeBounce).style('transform', 'translateY(30px)');
  arrow.classed('bounce', true);
}

function popItems(itemType) {
  var items = d3.selectAll(itemType);
  items.transition().duration(5000).delay(function (d, i) {
    return i * 100;
  }).ease(d3.easeBounce).style('transform', 'scale(1)');
}

function tweenDashIn() {
  var l = this.getTotalLength();
  var i = d3.interpolateString('0,' + l, l + ',' + l);
  return function (t) {
    return i(t);
  };
}

function drawInPaths(pathType) {
  var letterPaths = d3.selectAll(pathType);
  var lineNodes = letterPaths._groups[0];
  lineNodes.forEach.call(lineNodes, function (path) {
    letterPaths.transition().delay(function (d) {
      return Math.random() * Math.random(500);
    }).duration(5000).ease(d3.easeLinear).attrTween('stroke-dasharray', tweenDashIn);
  });
}

function animateTitle() {
  drawInPaths('#strokes path');
  drawInPaths('#line-strokes path');
  popItems('#stars polygon');
  popItems('#years g path');
  bounceArrow();
} // INTERACTIONS


function highlightName() {
  var $name = d3.select(this).attr('id').split('-')[0];
  var $logo = d3.select(".logoDiv-".concat($name));
  var $logoDivs = d3.selectAll('.logoDiv');
  $logoDivs.transition().duration(200).ease(d3.easeLinear).style('opacity', 0.2);
  $logo.transition().duration(500).ease(d3.easeLinear).style('opacity', 1);
  $logo.classed('is-highlighted', true);
}

function dehighlightName() {
  var $name = d3.select(this).attr('id').split('-')[0];
  var $logoDivs = d3.selectAll('.logoDiv');

  if ($name === 'bennet' || $name === 'bullock' || $name === 'ryan' || $name === 'biden' || $name === 'trump') {
    d3.selectAll('.RWB-Y').transition().duration(200).ease(d3.easeLinear).style('opacity', 1);
    d3.selectAll('.RWB-N').transition().duration(200).ease(d3.easeLinear).style('opacity', 0.2);
  }

  if ($name === 'harris' || $name === 'orourke' || $name === 'warren') {
    d3.selectAll('.RWB-Y').transition().duration(200).ease(d3.easeLinear).style('opacity', 0.2);
    d3.selectAll('.RWB-N').transition().duration(200).ease(d3.easeLinear).style('opacity', 1);
  }

  $logoDivs.classed('is-highlighted', false);
} // DATA


function filterData(data) {
  data2020 = data.filter(function (d) {
    return d.year === "2020";
  });
  data2020 = data2020.map(function (d) {
    return _objectSpread({}, d, {
      nameID: getLastName(d.name)
    });
  });
  data2020 = data2020.sort(function (a, b) {
    return d3.ascending(a.nameID, b.nameID);
  }); //Filter out Vermin for top

  data2020 = data2020.filter(function (d) {
    return d.nameID !== 'supreme';
  });
}

function getLastName(name) {
  var lastName = null;

  if (name === 'Bill de Blasio') {
    lastName = 'deblasio';
  } else if (name === 'Rocky De La Fuente') {
    lastName = 'delafuente';
  } else {
    lastName = name.split(' ')[1].toLowerCase().replace("'", "");
  }

  return lastName;
}

function init(data) {
  filterData(data);
  handleResize();
  scrollSetup(); //loadGrid();
  //fadeInGrid();
  //invisibleStroke(); 

  animateTitle();
  window.addEventListener('resize', handleResize); // INTERACTIONS

  $introNameSpan.on('mouseenter', highlightName);
  $introNameSpan.on('mouseleave', dehighlightName);
}

var _default = {
  init: init
};
exports.default = _default;
},{"intersection-observer":"CRRU","scrollama":"vL5c"}],"xZJw":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = loadData;

/* global d3 */

/* usage
	import loadData from './load-data'
	
	loadData('file.csv').then(result => {
		console.log(result);
	}).catch(console.error);

	loadData(['file1.csv', 'file2.json]).then(result => {
		console.log(result);
	}).catch(console.error);
*/
function loadFile(file) {
  return new Promise(function (resolve, reject) {
    var ext = file.split('.').pop();
    if (ext === 'csv') d3.csv("assets/data/".concat(file)).then(resolve).catch(reject);else if (ext === 'json') d3.json("assets/data/".concat(file)).then(resolve).catch(reject);else reject(new Error("unsupported file type for: ".concat(file)));
  });
}

function loadData(files) {
  if (typeof files === 'string') return loadFile(files);
  var loads = files.map(loadFile);
  return Promise.all(loads);
}
},{}],"V7o5":[function(require,module,exports) {
/* global d3 */

/*
 USAGE (example: line chart)
 1. c+p this template to a new file (line.js)
 2. change puddingChartName to puddingChartLine
 3. in graphic file: import './pudding-chart/line'
 4a. const charts = d3.selectAll('.thing').data(data).puddingChartLine();
 4b. const chart = d3.select('.thing').datum(datum).puddingChartLine();
*/
d3.selection.prototype.puddingColorChart = function init(options) {
  function createChart(el) {
    // dom elements
    var $chart = d3.select(el);
    var $colorChartContainer = null;
    var $yearDiv = null;
    var $yearLabel = null;
    var $candidateRow = null;
    var $candidateName = null;
    var $rwbGroup = null;
    var $otherGroup = null;
    var $redBlock = null;
    var $whiteBlock = null;
    var $blueBlock = null;
    var $overlay = d3.select('.overlay');
    var $overlayInset = $overlay.select('.overlay-inset');
    var $overlayName = $overlayInset.select('h5');
    var $overlayParty = $overlayInset.select('.party');
    var $overlayColor = $overlayInset.select('.color');
    var $overlayRace = $overlayInset.select('.race');
    var $overlayGender = $overlayInset.select('.gender');
    var $overlayImg = $overlayInset.select('img');
    var $overlayNotes = $overlayInset.select('.notes'); // data

    var _data = $chart.datum();

    var yearNestData = []; // dimensions

    var width = 0;
    var height = 0;
    var MARGIN_TOP = 0;
    var MARGIN_BOTTOM = 0;
    var MARGIN_LEFT = 0;
    var MARGIN_RIGHT = 0; // scales
    // const scaleX = null;
    // const scaleY = null;
    // helper functions

    function returnColor(color) {
      if (color == 'Y') {
        return 'RWB';
      } else {
        return 'Non-RWB';
      }
    }

    function returnRace(race) {
      if (race == 'Y') {
        return 'White';
      } else {
        return 'Cand. of color';
      }
    }

    function returnGender(gender) {
      if (gender == 'Y') {
        return 'Male';
      } else {
        return 'Female';
      }
    }

    function chartMouseover(d, i) {
      $candidateRow.classed('faded', true);
      d3.select(this).classed('faded', false);
      $overlayInset.classed('is-visible', true);
      $overlayName.text("".concat(d.name));
      $overlayParty.text("".concat(d.party, ", ").concat(d.year));
      $overlayColor.text("".concat(returnColor(d.RWB)));
      $overlayRace.text("".concat(returnRace(d.white)));
      $overlayGender.text("".concat(returnGender(d.male)));
      $overlayImg.attr('src', "assets/images/".concat(d.image)).attr('alt', "".concat(d.name, " campaign logo"));
    }

    function chartMouseout() {
      $candidateRow.classed('faded', false);
      $overlayInset.classed('is-visible', false);
    }

    function chartScroll() {
      $candidateRow.classed('faded', false);
      $overlayInset.classed('is-visible', false);
    }

    var Chart = {
      // called once at start
      init: function init() {
        yearNestData = d3.nest().key(function (d) {
          return d.year;
        }).entries(_data);
        $colorChartContainer = $chart.append('div').attr('class', 'pudding-chart'); //append year divs

        $yearDiv = $colorChartContainer.selectAll('.year').data(yearNestData).enter().append('div').attr('class', function (d) {
          return "year year-".concat(d.key);
        });
        $yearLabel = $yearDiv.append('p').attr('class', 'year-label').text(function (d) {
          return d.key;
        }); // append candidate rows

        $candidateRow = $yearDiv.selectAll('.candidate').data(function (d) {
          return d.values;
        }).enter().append('div').attr('class', function (d) {
          var nameStripped = d.name.replace(/\s+/g, '').replace(/\./g, '').replace(/\'/g, '');
          var partyStripped = null;

          if (d.party == 'Democratic') {
            partyStripped = d.party;
          } else if (d.party == 'Republican') {
            partyStripped = d.party;
          } else {
            partyStripped = 'Third';
          }

          return "candidate candidate_".concat(nameStripped, " candidate_RWB-").concat(d.RWB, " candidate_white-").concat(d.white, " candidate_male-").concat(d.male, " candidate_whiteMale-").concat(d.whiteMale, " candidate_party-").concat(partyStripped);
        }).on('mouseover', chartMouseover).on('mouseout', chartMouseout).on('scroll', chartScroll);
        $rwbGroup = $candidateRow.append('div').attr('class', 'rwb-group');
        $otherGroup = $candidateRow.append('div').attr('class', 'other-group');
        $redBlock = $rwbGroup.append('div').attr('class', function (d, i) {
          if (d.redHex) {
            return 'color-block';
          } else {
            return 'color-block empty-block';
          }
        }).style('background-color', function (d, i) {
          if (d.redHex) {
            return d.redHex;
          }
        });
        $whiteBlock = $rwbGroup.append('div').attr('class', function (d, i) {
          if (d.whiteHex) {
            return 'color-block';
          } else {
            return 'color-block empty-block';
          }
        }).style('background-color', function (d, i) {
          if (d.whiteHex) {
            return d.whiteHex;
          }
        });
        $blueBlock = $rwbGroup.append('div').attr('class', function (d, i) {
          if (d.blueHex) {
            return 'color-block';
          } else {
            return 'color-block empty-block';
          }
        }).style('background-color', function (d, i) {
          if (d.blueHex) {
            return d.blueHex;
          }
        });
        $other1Block = $otherGroup.append('div').attr('class', function (d, i) {
          if (d.other1Hex) {
            return 'color-block';
          } else {
            return 'color-block empty-block';
          }
        }).style('background-color', function (d, i) {
          if (d.other1Hex) {
            return d.other1Hex;
          }
        });
        $other2Block = $otherGroup.append('div').attr('class', function (d, i) {
          if (d.other2Hex) {
            return 'color-block';
          } else {
            return 'color-block empty-block';
          }
        }).style('background-color', function (d, i) {
          if (d.other2Hex) {
            return d.other2Hex;
          }
        });
        $other3Block = $otherGroup.append('div').attr('class', function (d, i) {
          if (d.other3Hex) {
            return 'color-block';
          } else {
            return 'color-block empty-block';
          }
        }).style('background-color', function (d, i) {
          if (d.other3Hex) {
            return d.other3Hex;
          }
        });
        Chart.resize();
      },
      // on resize, update new dimensions
      resize: function resize() {
        // defaults to grabbing dimensions from container element
        width = $chart.node().offsetWidth - MARGIN_LEFT - MARGIN_RIGHT;
        height = $chart.node().offsetHeight - MARGIN_TOP - MARGIN_BOTTOM;
        var totalCandidates = _data.length;
        var barHeight = Math.floor(height / totalCandidates * 2);
        var colorBlocks = d3.selectAll('.color-block'); //d3.selectAll('.color-block').style('height', `8px`)
        //d3.selectAll('.candidate').style('height', `10px`)

        return Chart;
      },
      // update scales and render chart
      render: function render() {
        return Chart;
      },
      // get / set data
      data: function data(val) {
        if (!arguments.length) return _data;
        _data = val;
        $chart.datum(_data);
        return Chart;
      }
    };
    Chart.init();
    return Chart;
  } // create charts


  var charts = this.nodes().map(createChart);
  return charts.length > 1 ? charts : charts.pop();
};
},{}],"ia5p":[function(require,module,exports) {
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(source, true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(source).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/* global d3 */

/*
 USAGE (example: line chart)
 1. c+p this template to a new file (line.js)
 2. change puddingChartName to puddingChartLine
 3. in graphic file: import './pudding-chart/line'
 4a. const charts = d3.selectAll('.thing').data(data).puddingChartLine();
 4b. const chart = d3.select('.thing').datum(datum).puddingChartLine();
*/
d3.selection.prototype.puddingBarChart = function init(options) {
  function createChart(el) {
    // dom elements
    var $chart = d3.select(el);
    var $yearRow = null;
    var $yearLabel = null;
    var $barContainer = null;
    var $rwbBar = null;
    var $rwbNBar = null; // data

    var _data = $chart.datum();

    _data = _data.map(function (d) {
      return _objectSpread({}, d, {
        percent_n: +d.percent_n,
        percent_y: +d.percent_y
      });
    }); // dimensions

    var width = 0;
    var height = 0;
    var MARGIN_TOP = 0;
    var MARGIN_BOTTOM = 0;
    var MARGIN_LEFT = 0;
    var MARGIN_RIGHT = 0; // scales

    var scaleX = null;
    var scaleY = null; // helper functions

    var Chart = {
      // called once at start
      init: function init() {
        $yearRow = $chart.selectAll('.year-row').data(_data).enter().append('div').attr('class', 'year-row');
        $yearLabel = $yearRow.append('p').text(function (d) {
          return d.year;
        }).attr('class', 'year-label');
        $barContainer = $yearRow.append('div').attr('class', 'bar-container');
        $rwbBar = $barContainer.append('div').attr('class', 'bar-rwb');
        $rwbNBar = $barContainer.append('div').attr('class', 'bar-rwbn').style('width', function (d) {
          return "".concat(d.percent_n * 100, "%");
        });
        $rwbNBar.append('p').text(function (d) {
          return "".concat((d.percent_n * 100).toFixed(1), "%");
        }).style('left', function (d) {
          return "".concat(100, "%");
        });
      },
      // on resize, update new dimensions
      resize: function resize() {
        // defaults to grabbing dimensions from container element
        width = $chart.node().offsetWidth - MARGIN_LEFT - MARGIN_RIGHT;
        height = $chart.node().offsetHeight - MARGIN_TOP - MARGIN_BOTTOM;
        $svg.attr('width', width + MARGIN_LEFT + MARGIN_RIGHT).attr('height', height + MARGIN_TOP + MARGIN_BOTTOM);
        return Chart;
      },
      // update scales and render chart
      render: function render() {
        // offset chart for margins
        $vis.attr('transform', "translate(".concat(MARGIN_LEFT, ", ").concat(MARGIN_TOP, ")"));
        return Chart;
      },
      // get / set data
      data: function data(val) {
        if (!arguments.length) return _data;
        _data = val;
        $chart.datum(_data);
        return Chart;
      }
    };
    Chart.init();
    return Chart;
  } // create charts


  var charts = this.nodes().map(createChart);
  return charts.length > 1 ? charts : charts.pop();
};
},{}],"miniGrid.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(source, true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(source).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var demographicData = [];
var demographicDataNest = [];
var whiteMaleData = [];
var whiteMaleDataNest = [];
var demoHed = null;

function getLastName(name) {
  var lastName = null;

  if (name === 'Bill de Blasio') {
    lastName = 'deblasio';
  } else if (name === 'Rocky De La Fuente') {
    lastName = 'delafuente';
  } else if (name === 'Carol Moseley Braun') {
    lastName = 'moseleybraun';
  } else {
    lastName = name.split(' ')[1].toLowerCase().replace("'", "");
  }

  return lastName;
}

function filterData(data, demographic) {
  whiteMaleData = data.filter(function (d) {
    return d.whiteMale == 'TRUE';
  });
  whiteMaleDataNest = d3.nest().key(function (d) {
    return d.RWB;
  }).sortKeys(d3.ascending).entries(whiteMaleData);

  if (demographic == 'allMin') {
    demographicData = data.filter(function (d) {
      return d.whiteMale == 'FALSE';
    });
    demographicData = demographicData.map(function (d) {
      return _objectSpread({}, d, {
        nameID: getLastName(d.name)
      });
    });
    demographicDataNest = d3.nest().key(function (d) {
      return d.RWB;
    }).sortKeys(d3.ascending).entries(demographicData);
    demoHed = 'all minority candidates';
  }

  if (demographic == 'race') {
    demographicData = data.filter(function (d) {
      return d.white == 'N';
    });
    demographicData = demographicData.map(function (d) {
      return _objectSpread({}, d, {
        nameID: getLastName(d.name)
      });
    });
    demographicDataNest = d3.nest().key(function (d) {
      return d.RWB;
    }).sortKeys(d3.ascending).entries(demographicData);
    demoHed = 'candidates of color';
  }

  if (demographic == 'gender') {
    demographicData = data.filter(function (d) {
      return d.male == 'N';
    });
    demographicData = demographicData.map(function (d) {
      return _objectSpread({}, d, {
        nameID: getLastName(d.name)
      });
    });
    demographicDataNest = d3.nest().key(function (d) {
      return d.RWB;
    }).sortKeys(d3.ascending).entries(demographicData);
    demoHed = 'women candidates';
  }

  if (demographic == 'minWomen') {
    demographicData = data.filter(function (d) {
      return d.male == 'N' && d.white == 'N';
    });
    demographicData = demographicData.map(function (d) {
      return _objectSpread({}, d, {
        nameID: getLastName(d.name)
      });
    });
    demographicDataNest = d3.nest().key(function (d) {
      return d.RWB;
    }).sortKeys(d3.ascending).entries(demographicData);
    demoHed = 'women of color candidates';
  }
}

function init(data, demographic) {
  filterData(data, demographic);
  var totalCands = demographicDataNest[0].values.length + demographicDataNest[1].values.length;
  var percentCands = Math.round(demographicDataNest[0].values.length / totalCands * 100);
  var whiteMaleCands = whiteMaleDataNest[0].values.length + whiteMaleDataNest[1].values.length;
  var percentWhiteMaleCands = Math.round(whiteMaleDataNest[0].values.length / whiteMaleCands * 100);
  var $demoContainer = d3.select("#".concat(demographic));
  var $demoSen = d3.select("#".concat(demographic, "-sen"));
  $demoSen.html("<span>".concat(percentCands, "% of ").concat(demoHed, "</span> used non-RWB colors compared to only ").concat(percentWhiteMaleCands, "% of White men candidates."));
  var $colorContainer = $demoContainer.selectAll('.colorGroup').data(demographicDataNest).enter().append('div').attr('class', "colorGroup");
  $colorContainer.append('p').text(function (d) {
    if (d.key === 'N') {
      return "Non-RWB (".concat(d.values.length, " candidates)");
    } else {
      return "RWB (".concat(d.values.length, " candidates)");
    }
  });
  var $imgDiv = $colorContainer.selectAll('.logoSmall').data(function (d) {
    return d.values;
  }).enter().append('div').attr('class', function (d) {
    return "logoSmall logoSmall-".concat(d.nameID);
  });
  $imgDiv.append('img').attr('src', function (d) {
    return "assets/images/".concat(d.year, "-").concat(d.nameID, ".jpg");
  }).attr('alt', function (d) {
    return "".concat(d.name, " campaign logo");
  });
}

var _default = {
  init: init
};
exports.default = _default;
},{}],"RZIL":[function(require,module,exports) {
var define;
"use strict";!function(e){"function"==typeof define&&define.amd?define(e):"undefined"!=typeof module&&module.exports?module.exports=e():window.enterView=e.call(this)}(function(){var e=function(e){function n(){E=window.requestAnimationFrame||window.webkitRequestAnimationFrame||window.mozRequestAnimationFrame||window.msRequestAnimationFrame||function(e){return setTimeout(e,1e3/60)}}function t(){if(y&&"number"==typeof y){var e=Math.min(Math.max(0,y),1);return F-e*F}return F}function o(){var e=document.documentElement.clientHeight,n=window.innerHeight||0;F=Math.max(e,n)}function r(){L=!1;var e=t();M=M.filter(function(n){var t=n.getBoundingClientRect(),o=t.top,r=t.bottom,i=t.height,s=o<e,u=r<e;if(s&&!n.__ev_entered){if(m(n),n.__ev_progress=0,h(n,n.__ev_progress),q)return!1}else!s&&n.__ev_entered&&(n.__ev_progress=0,h(n,n.__ev_progress),g(n));if(s&&!u){var d=(e-o)/i;n.__ev_progress=Math.min(1,Math.max(0,d)),h(n,n.__ev_progress)}return s&&u&&1!==n.__ev_progress&&(n.__ev_progress=1,h(n,n.__ev_progress)),n.__ev_entered=s,!0}),M.length||window.removeEventListener("scroll",i,!0)}function i(){L||(L=!0,E(r))}function s(){o(),r()}function u(){o(),r()}function d(e){for(var n=e.length,t=[],o=0;o<n;o+=1)t.push(e[o]);return t}function f(e){var n=arguments.length>1&&void 0!==arguments[1]?arguments[1]:document;return"string"==typeof e?d(n.querySelectorAll(e)):e instanceof NodeList?d(e):e instanceof Array?e:void 0}function c(){M=f(v)}function a(){window.addEventListener("resize",s,!0),window.addEventListener("scroll",i,!0),window.addEventListener("load",u,!0),s()}function _(){return v?(c(),M&&M.length?(n(),a(),void r()):(console.error("no selector elements found"),!1)):(console.error("must pass a selector"),!1)}var v=e.selector,l=e.enter,m=void 0===l?function(){}:l,w=e.exit,g=void 0===w?function(){}:w,p=e.progress,h=void 0===p?function(){}:p,x=e.offset,y=void 0===x?0:x,A=e.once,q=void 0!==A&&A,E=null,L=!1,M=[],F=0;_()};return e});
},{}],"fTMh":[function(require,module,exports) {
var define;
(function webpackUniversalModuleDefinition(e, t) {
  "object" == typeof exports && "object" == typeof module ? module.exports = t() : "function" == typeof define && define.amd ? define([], t) : "object" == typeof exports ? exports["accessibleAutocomplete"] = t() : e["accessibleAutocomplete"] = t();
})(window, function () {
  return function (n) {
    var r = {};

    function o(e) {
      if (r[e]) return r[e].exports;
      var t = r[e] = {
        i: e,
        l: !1,
        exports: {}
      };
      return n[e].call(t.exports, t, t.exports, o), t.l = !0, t.exports;
    }

    return o.m = n, o.c = r, o.d = function (e, t, n) {
      o.o(e, t) || Object.defineProperty(e, t, {
        enumerable: !0,
        get: n
      });
    }, o.r = function (e) {
      "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
        value: "Module"
      }), Object.defineProperty(e, "__esModule", {
        value: !0
      });
    }, o.t = function (t, e) {
      if (1 & e && (t = o(t)), 8 & e) return t;
      if (4 & e && "object" == typeof t && t && t.__esModule) return t;
      var n = Object.create(null);
      if (o.r(n), Object.defineProperty(n, "default", {
        enumerable: !0,
        value: t
      }), 2 & e && "string" != typeof t) for (var r in t) o.d(n, r, function (e) {
        return t[e];
      }.bind(null, r));
      return n;
    }, o.n = function (e) {
      var t = e && e.__esModule ? function () {
        return e["default"];
      } : function () {
        return e;
      };
      return o.d(t, "a", t), t;
    }, o.o = function (e, t) {
      return Object.prototype.hasOwnProperty.call(e, t);
    }, o.p = "/", o(o.s = 37);
  }([function (e, t, n) {
    var m = n(1),
        v = n(6),
        y = n(7),
        g = n(16),
        _ = n(18),
        b = "prototype",
        w = function (e, t, n) {
      var r,
          o,
          i,
          u,
          a = e & w.F,
          s = e & w.G,
          l = e & w.S,
          c = e & w.P,
          p = e & w.B,
          f = s ? m : l ? m[t] || (m[t] = {}) : (m[t] || {})[b],
          d = s ? v : v[t] || (v[t] = {}),
          h = d[b] || (d[b] = {});

      for (r in s && (n = t), n) i = ((o = !a && f && f[r] !== undefined) ? f : n)[r], u = p && o ? _(i, m) : c && "function" == typeof i ? _(Function.call, i) : i, f && g(f, r, i, e & w.U), d[r] != i && y(d, r, u), c && h[r] != i && (h[r] = i);
    };

    m.core = v, w.F = 1, w.G = 2, w.S = 4, w.P = 8, w.B = 16, w.W = 32, w.U = 64, w.R = 128, e.exports = w;
  }, function (e, t) {
    var n = e.exports = "undefined" != typeof window && window.Math == Math ? window : "undefined" != typeof self && self.Math == Math ? self : Function("return this")();
    "number" == typeof __g && (__g = n);
  }, function (e, t) {
    e.exports = function (e) {
      return "object" == typeof e ? null !== e : "function" == typeof e;
    };
  }, function (e, t, n) {
    e.exports = !n(4)(function () {
      return 7 != Object.defineProperty({}, "a", {
        get: function () {
          return 7;
        }
      }).a;
    });
  }, function (e, t) {
    e.exports = function (e) {
      try {
        return !!e();
      } catch (t) {
        return !0;
      }
    };
  }, function (e, t, n) {
    "use strict";

    n.r(t), n.d(t, "h", function () {
      return r;
    }), n.d(t, "createElement", function () {
      return r;
    }), n.d(t, "cloneElement", function () {
      return i;
    }), n.d(t, "Component", function () {
      return g;
    }), n.d(t, "render", function () {
      return _;
    }), n.d(t, "rerender", function () {
      return f;
    }), n.d(t, "options", function () {
      return E;
    });

    var s = function s() {},
        E = {},
        l = [],
        c = [];

    function r(e, t) {
      var n,
          r,
          o,
          i,
          u = c;

      for (i = arguments.length; 2 < i--;) l.push(arguments[i]);

      for (t && null != t.children && (l.length || l.push(t.children), delete t.children); l.length;) if ((r = l.pop()) && r.pop !== undefined) for (i = r.length; i--;) l.push(r[i]);else "boolean" == typeof r && (r = null), (o = "function" != typeof e) && (null == r ? r = "" : "number" == typeof r ? r = String(r) : "string" != typeof r && (o = !1)), o && n ? u[u.length - 1] += r : u === c ? u = [r] : u.push(r), n = o;

      var a = new s();
      return a.nodeName = e, a.children = u, a.attributes = null == t ? undefined : t, a.key = null == t ? undefined : t.key, E.vnode !== undefined && E.vnode(a), a;
    }

    function M(e, t) {
      for (var n in t) e[n] = t[n];

      return e;
    }

    var o = "function" == typeof Promise ? Promise.resolve().then.bind(Promise.resolve()) : setTimeout;

    function i(e, t) {
      return r(e.nodeName, M(M({}, e.attributes), t), 2 < arguments.length ? [].slice.call(arguments, 2) : e.children);
    }

    var p = /acit|ex(?:s|g|n|p|$)|rph|ows|mnc|ntw|ine[ch]|zoo|^ord/i,
        u = [];

    function a(e) {
      !e._dirty && (e._dirty = !0) && 1 == u.push(e) && (E.debounceRendering || o)(f);
    }

    function f() {
      var e,
          t = u;

      for (u = []; e = t.pop();) e._dirty && V(e);
    }

    function N(e, t) {
      return e.normalizedNodeName === t || e.nodeName.toLowerCase() === t.toLowerCase();
    }

    function I(e) {
      var t = M({}, e.attributes);
      t.children = e.children;
      var n = e.nodeName.defaultProps;
      if (n !== undefined) for (var r in n) t[r] === undefined && (t[r] = n[r]);
      return t;
    }

    function k(e) {
      var t = e.parentNode;
      t && t.removeChild(e);
    }

    function v(e, t, n, r, o) {
      if ("className" === t && (t = "class"), "key" === t) ;else if ("ref" === t) n && n(null), r && r(e);else if ("class" !== t || o) {
        if ("style" === t) {
          if (r && "string" != typeof r && "string" != typeof n || (e.style.cssText = r || ""), r && "object" == typeof r) {
            if ("string" != typeof n) for (var i in n) i in r || (e.style[i] = "");

            for (var i in r) e.style[i] = "number" == typeof r[i] && !1 === p.test(i) ? r[i] + "px" : r[i];
          }
        } else if ("dangerouslySetInnerHTML" === t) r && (e.innerHTML = r.__html || "");else if ("o" == t[0] && "n" == t[1]) {
          var u = t !== (t = t.replace(/Capture$/, ""));
          t = t.toLowerCase().substring(2), r ? n || e.addEventListener(t, d, u) : e.removeEventListener(t, d, u), (e._listeners || (e._listeners = {}))[t] = r;
        } else if ("list" !== t && "type" !== t && !o && t in e) {
          try {
            e[t] = null == r ? "" : r;
          } catch (s) {}

          null != r && !1 !== r || "spellcheck" == t || e.removeAttribute(t);
        } else {
          var a = o && t !== (t = t.replace(/^xlink:?/, ""));
          null == r || !1 === r ? a ? e.removeAttributeNS("http://www.w3.org/1999/xlink", t.toLowerCase()) : e.removeAttribute(t) : "function" != typeof r && (a ? e.setAttributeNS("http://www.w3.org/1999/xlink", t.toLowerCase(), r) : e.setAttribute(t, r));
        }
      } else e.className = r || "";
    }

    function d(e) {
      return this._listeners[e.type](E.event && E.event(e) || e);
    }

    var A = [],
        P = 0,
        j = !1,
        L = !1;

    function T() {
      for (var e; e = A.pop();) E.afterMount && E.afterMount(e), e.componentDidMount && e.componentDidMount();
    }

    function B(e, t, n, r, o, i) {
      P++ || (j = null != o && o.ownerSVGElement !== undefined, L = null != e && !("__preactattr_" in e));
      var u = D(e, t, n, r, i);
      return o && u.parentNode !== o && o.appendChild(u), --P || (L = !1, i || T()), u;
    }

    function D(e, t, n, r, o) {
      var i = e,
          u = j;
      if (null != t && "boolean" != typeof t || (t = ""), "string" == typeof t || "number" == typeof t) return e && e.splitText !== undefined && e.parentNode && (!e._component || o) ? e.nodeValue != t && (e.nodeValue = t) : (i = document.createTextNode(t), e && (e.parentNode && e.parentNode.replaceChild(i, e), F(e, !0))), i["__preactattr_"] = !0, i;
      var a = t.nodeName;
      if ("function" == typeof a) return function d(e, t, n, r) {
        var o = e && e._component,
            i = o,
            u = e,
            a = o && e._componentConstructor === t.nodeName,
            s = a,
            l = I(t);

        for (; o && !s && (o = o._parentComponent);) s = o.constructor === t.nodeName;

        o && s && (!r || o._component) ? (U(o, l, 3, n, r), e = o.base) : (i && !a && (q(i), e = u = null), o = R(t.nodeName, l, n), e && !o.nextBase && (o.nextBase = e, u = null), U(o, l, 1, n, r), e = o.base, u && e !== u && (u._component = null, F(u, !1)));
        return e;
      }(e, t, n, r);

      if (j = "svg" === a || "foreignObject" !== a && j, a = String(a), (!e || !N(e, a)) && (i = function h(e, t) {
        var n = t ? document.createElementNS("http://www.w3.org/2000/svg", e) : document.createElement(e);
        return n.normalizedNodeName = e, n;
      }(a, j), e)) {
        for (; e.firstChild;) i.appendChild(e.firstChild);

        e.parentNode && e.parentNode.replaceChild(i, e), F(e, !0);
      }

      var s = i.firstChild,
          l = i["__preactattr_"],
          c = t.children;

      if (null == l) {
        l = i["__preactattr_"] = {};

        for (var p = i.attributes, f = p.length; f--;) l[p[f].name] = p[f].value;
      }

      return !L && c && 1 === c.length && "string" == typeof c[0] && null != s && s.splitText !== undefined && null == s.nextSibling ? s.nodeValue != c[0] && (s.nodeValue = c[0]) : (c && c.length || null != s) && function S(e, t, n, r, o) {
        var i,
            u,
            a,
            s,
            l,
            c = e.childNodes,
            p = [],
            f = {},
            d = 0,
            h = 0,
            m = c.length,
            v = 0,
            y = t ? t.length : 0;
        if (0 !== m) for (var g = 0; g < m; g++) {
          var _ = c[g],
              b = _["__preactattr_"],
              w = y && b ? _._component ? _._component.__key : b.key : null;
          null != w ? (d++, f[w] = _) : (b || (_.splitText !== undefined ? !o || _.nodeValue.trim() : o)) && (p[v++] = _);
        }
        if (0 !== y) for (var g = 0; g < y; g++) {
          s = t[g], l = null;
          var w = s.key;
          if (null != w) d && f[w] !== undefined && (l = f[w], f[w] = undefined, d--);else if (h < v) for (i = h; i < v; i++) if (p[i] !== undefined && (x = u = p[i], C = o, "string" == typeof (O = s) || "number" == typeof O ? x.splitText !== undefined : "string" == typeof O.nodeName ? !x._componentConstructor && N(x, O.nodeName) : C || x._componentConstructor === O.nodeName)) {
            l = u, p[i] = undefined, i === v - 1 && v--, i === h && h++;
            break;
          }
          l = D(l, s, n, r), a = c[g], l && l !== e && l !== a && (null == a ? e.appendChild(l) : l === a.nextSibling ? k(a) : e.insertBefore(l, a));
        }
        var x, O, C;
        if (d) for (var g in f) f[g] !== undefined && F(f[g], !1);

        for (; h <= v;) (l = p[v--]) !== undefined && F(l, !1);
      }(i, c, n, r, L || null != l.dangerouslySetInnerHTML), function m(e, t, n) {
        var r;

        for (r in n) t && null != t[r] || null == n[r] || v(e, r, n[r], n[r] = undefined, j);

        for (r in t) "children" === r || "innerHTML" === r || r in n && t[r] === ("value" === r || "checked" === r ? e[r] : n[r]) || v(e, r, n[r], n[r] = t[r], j);
      }(i, t.attributes, l), j = u, i;
    }

    function F(e, t) {
      var n = e._component;
      n ? q(n) : (null != e["__preactattr_"] && e["__preactattr_"].ref && e["__preactattr_"].ref(null), !1 !== t && null != e["__preactattr_"] || k(e), h(e));
    }

    function h(e) {
      for (e = e.lastChild; e;) {
        var t = e.previousSibling;
        F(e, !0), e = t;
      }
    }

    var m = [];

    function R(e, t, n) {
      var r,
          o = m.length;

      for (e.prototype && e.prototype.render ? (r = new e(t, n), g.call(r, t, n)) : ((r = new g(t, n)).constructor = e, r.render = y); o--;) if (m[o].constructor === e) return r.nextBase = m[o].nextBase, m.splice(o, 1), r;

      return r;
    }

    function y(e, t, n) {
      return this.constructor(e, n);
    }

    function U(e, t, n, r, o) {
      e._disable || (e._disable = !0, e.__ref = t.ref, e.__key = t.key, delete t.ref, delete t.key, "undefined" == typeof e.constructor.getDerivedStateFromProps && (!e.base || o ? e.componentWillMount && e.componentWillMount() : e.componentWillReceiveProps && e.componentWillReceiveProps(t, r)), r && r !== e.context && (e.prevContext || (e.prevContext = e.context), e.context = r), e.prevProps || (e.prevProps = e.props), e.props = t, e._disable = !1, 0 !== n && (1 !== n && !1 === E.syncComponentUpdates && e.base ? a(e) : V(e, 1, o)), e.__ref && e.__ref(e));
    }

    function V(e, t, n, r) {
      if (!e._disable) {
        var o,
            i,
            u,
            a = e.props,
            s = e.state,
            l = e.context,
            c = e.prevProps || a,
            p = e.prevState || s,
            f = e.prevContext || l,
            d = e.base,
            h = e.nextBase,
            m = d || h,
            v = e._component,
            y = !1,
            g = f;

        if (e.constructor.getDerivedStateFromProps && (s = M(M({}, s), e.constructor.getDerivedStateFromProps(a, s)), e.state = s), d && (e.props = c, e.state = p, e.context = f, 2 !== t && e.shouldComponentUpdate && !1 === e.shouldComponentUpdate(a, s, l) ? y = !0 : e.componentWillUpdate && e.componentWillUpdate(a, s, l), e.props = a, e.state = s, e.context = l), e.prevProps = e.prevState = e.prevContext = e.nextBase = null, e._dirty = !1, !y) {
          o = e.render(a, s, l), e.getChildContext && (l = M(M({}, l), e.getChildContext())), d && e.getSnapshotBeforeUpdate && (g = e.getSnapshotBeforeUpdate(c, p));

          var _,
              b,
              w = o && o.nodeName;

          if ("function" == typeof w) {
            var x = I(o);
            (i = v) && i.constructor === w && x.key == i.__key ? U(i, x, 1, l, !1) : (_ = i, e._component = i = R(w, x, l), i.nextBase = i.nextBase || h, i._parentComponent = e, U(i, x, 0, l, !1), V(i, 1, n, !0)), b = i.base;
          } else u = m, (_ = v) && (u = e._component = null), (m || 1 === t) && (u && (u._component = null), b = function B(t, n, r, o, i, u) {
            P++ || (j = null != i && i.ownerSVGElement !== undefined, L = null != t && !("__preactattr_" in t));
            var a = D(t, n, r, o, u);
            return i && a.parentNode !== i && i.appendChild(a), --P || (L = !1, u || T()), a;
          }(u, o, l, n || !d, m && m.parentNode, !0));

          if (m && b !== m && i !== v) {
            var O = m.parentNode;
            O && b !== O && (O.replaceChild(b, m), _ || (m._component = null, F(m, !1)));
          }

          if (_ && q(_), (e.base = b) && !r) {
            for (var C = e, S = e; S = S._parentComponent;) (C = S).base = b;

            b._component = C, b._componentConstructor = C.constructor;
          }
        }

        for (!d || n ? A.unshift(e) : y || (e.componentDidUpdate && e.componentDidUpdate(c, p, g), E.afterUpdate && E.afterUpdate(e)); e._renderCallbacks.length;) e._renderCallbacks.pop().call(e);

        P || r || T();
      }
    }

    function q(e) {
      E.beforeUnmount && E.beforeUnmount(e);
      var t = e.base;
      e._disable = !0, e.componentWillUnmount && e.componentWillUnmount(), e.base = null;
      var n = e._component;
      n ? q(n) : t && (t["__preactattr_"] && t["__preactattr_"].ref && t["__preactattr_"].ref(null), k(e.nextBase = t), m.push(e), h(t)), e.__ref && e.__ref(null);
    }

    function g(e, t) {
      this._dirty = !0, this.context = t, this.props = e, this.state = this.state || {}, this._renderCallbacks = [];
    }

    function _(e, t, n) {
      return B(n, e, {}, !1, t, !1);
    }

    M(g.prototype, {
      setState: function (e, t) {
        this.prevState || (this.prevState = this.state), this.state = M(M({}, this.state), "function" == typeof e ? e(this.state, this.props) : e), t && this._renderCallbacks.push(t), a(this);
      },
      forceUpdate: function (e) {
        e && this._renderCallbacks.push(e), V(this, 2);
      },
      render: function _() {}
    });
    var b = {
      h: r,
      createElement: r,
      cloneElement: i,
      Component: g,
      render: _,
      rerender: f,
      options: E
    };
    t["default"] = b;
  }, function (e, t) {
    var n = e.exports = {
      version: "2.5.7"
    };
    "number" == typeof __e && (__e = n);
  }, function (e, t, n) {
    var r = n(8),
        o = n(40);
    e.exports = n(3) ? function (e, t, n) {
      return r.f(e, t, o(1, n));
    } : function (e, t, n) {
      return e[t] = n, e;
    };
  }, function (e, t, n) {
    var o = n(9),
        i = n(38),
        u = n(39),
        a = Object.defineProperty;
    t.f = n(3) ? Object.defineProperty : function (e, t, n) {
      if (o(e), t = u(t, !0), o(n), i) try {
        return a(e, t, n);
      } catch (r) {}
      if ("get" in n || "set" in n) throw TypeError("Accessors not supported!");
      return "value" in n && (e[t] = n.value), e;
    };
  }, function (e, t, n) {
    var r = n(2);

    e.exports = function (e) {
      if (!r(e)) throw TypeError(e + " is not an object!");
      return e;
    };
  }, function (e, t) {
    var n = 0,
        r = Math.random();

    e.exports = function (e) {
      return "Symbol(".concat(e === undefined ? "" : e, ")_", (++n + r).toString(36));
    };
  }, function (e, t, n) {
    var r = n(22);
    e.exports = Object("z").propertyIsEnumerable(0) ? Object : function (e) {
      return "String" == r(e) ? e.split("") : Object(e);
    };
  }, function (e, t) {
    e.exports = function (e) {
      if (e == undefined) throw TypeError("Can't call method on  " + e);
      return e;
    };
  }, function (e, t, n) {
    "use strict";

    var r = n(4);

    e.exports = function (e, t) {
      return !!e && r(function () {
        t ? e.call(null, function () {}, 1) : e.call(null);
      });
    };
  }, function (e, t, n) {
    var r = n(0);
    r(r.S + r.F, "Object", {
      assign: n(41)
    });
  }, function (e, t, n) {
    var r = n(2),
        o = n(1).document,
        i = r(o) && r(o.createElement);

    e.exports = function (e) {
      return i ? o.createElement(e) : {};
    };
  }, function (e, t, n) {
    var i = n(1),
        u = n(7),
        a = n(17),
        s = n(10)("src"),
        r = "toString",
        o = Function[r],
        l = ("" + o).split(r);
    n(6).inspectSource = function (e) {
      return o.call(e);
    }, (e.exports = function (e, t, n, r) {
      var o = "function" == typeof n;
      o && (a(n, "name") || u(n, "name", t)), e[t] !== n && (o && (a(n, s) || u(n, s, e[t] ? "" + e[t] : l.join(String(t)))), e === i ? e[t] = n : r ? e[t] ? e[t] = n : u(e, t, n) : (delete e[t], u(e, t, n)));
    })(Function.prototype, r, function () {
      return "function" == typeof this && this[s] || o.call(this);
    });
  }, function (e, t) {
    var n = {}.hasOwnProperty;

    e.exports = function (e, t) {
      return n.call(e, t);
    };
  }, function (e, t, n) {
    var i = n(19);

    e.exports = function (r, o, e) {
      if (i(r), o === undefined) return r;

      switch (e) {
        case 1:
          return function (e) {
            return r.call(o, e);
          };

        case 2:
          return function (e, t) {
            return r.call(o, e, t);
          };

        case 3:
          return function (e, t, n) {
            return r.call(o, e, t, n);
          };
      }

      return function () {
        return r.apply(o, arguments);
      };
    };
  }, function (e, t) {
    e.exports = function (e) {
      if ("function" != typeof e) throw TypeError(e + " is not a function!");
      return e;
    };
  }, function (e, t, n) {
    var r = n(42),
        o = n(28);

    e.exports = Object.keys || function (e) {
      return r(e, o);
    };
  }, function (e, t, n) {
    var r = n(11),
        o = n(12);

    e.exports = function (e) {
      return r(o(e));
    };
  }, function (e, t) {
    var n = {}.toString;

    e.exports = function (e) {
      return n.call(e).slice(8, -1);
    };
  }, function (e, t, n) {
    var s = n(21),
        l = n(24),
        c = n(43);

    e.exports = function (a) {
      return function (e, t, n) {
        var r,
            o = s(e),
            i = l(o.length),
            u = c(n, i);

        if (a && t != t) {
          for (; u < i;) if ((r = o[u++]) != r) return !0;
        } else for (; u < i; u++) if ((a || u in o) && o[u] === t) return a || u || 0;

        return !a && -1;
      };
    };
  }, function (e, t, n) {
    var r = n(25),
        o = Math.min;

    e.exports = function (e) {
      return 0 < e ? o(r(e), 9007199254740991) : 0;
    };
  }, function (e, t) {
    var n = Math.ceil,
        r = Math.floor;

    e.exports = function (e) {
      return isNaN(e = +e) ? 0 : (0 < e ? r : n)(e);
    };
  }, function (e, t, n) {
    var r = n(27)("keys"),
        o = n(10);

    e.exports = function (e) {
      return r[e] || (r[e] = o(e));
    };
  }, function (e, t, n) {
    var r = n(6),
        o = n(1),
        i = "__core-js_shared__",
        u = o[i] || (o[i] = {});
    (e.exports = function (e, t) {
      return u[e] || (u[e] = t !== undefined ? t : {});
    })("versions", []).push({
      version: r.version,
      mode: n(44) ? "pure" : "global",
      copyright: "© 2018 Denis Pushkarev (zloirock.ru)"
    });
  }, function (e, t) {
    e.exports = "constructor,hasOwnProperty,isPrototypeOf,propertyIsEnumerable,toLocaleString,toString,valueOf".split(",");
  }, function (e, t, n) {
    var r = n(12);

    e.exports = function (e) {
      return Object(r(e));
    };
  }, function (e, t, n) {
    var r = n(8).f,
        o = Function.prototype,
        i = /^\s*function ([^ (]*)/;
    "name" in o || n(3) && r(o, "name", {
      configurable: !0,
      get: function () {
        try {
          return ("" + this).match(i)[1];
        } catch (e) {
          return "";
        }
      }
    });
  }, function (e, t, n) {
    "use strict";

    var r = n(0),
        o = n(32)(1);
    r(r.P + r.F * !n(13)([].map, !0), "Array", {
      map: function (e) {
        return o(this, e, arguments[1]);
      }
    });
  }, function (e, t, n) {
    var _ = n(18),
        b = n(11),
        w = n(29),
        x = n(24),
        r = n(47);

    e.exports = function (p, e) {
      var f = 1 == p,
          d = 2 == p,
          h = 3 == p,
          m = 4 == p,
          v = 6 == p,
          y = 5 == p || v,
          g = e || r;
      return function (e, t, n) {
        for (var r, o, i = w(e), u = b(i), a = _(t, n, 3), s = x(u.length), l = 0, c = f ? g(e, s) : d ? g(e, 0) : undefined; l < s; l++) if ((y || l in u) && (o = a(r = u[l], l, i), p)) if (f) c[l] = o;else if (o) switch (p) {
          case 3:
            return !0;

          case 5:
            return r;

          case 6:
            return l;

          case 2:
            c.push(r);
        } else if (m) return !1;

        return v ? -1 : h || m ? m : c;
      };
    };
  }, function (e, t, n) {
    var r = n(22);

    e.exports = Array.isArray || function (e) {
      return "Array" == r(e);
    };
  }, function (e, t, n) {
    var r = n(27)("wks"),
        o = n(10),
        i = n(1).Symbol,
        u = "function" == typeof i;
    (e.exports = function (e) {
      return r[e] || (r[e] = u && i[e] || (u ? i : o)("Symbol." + e));
    }).store = r;
  }, function (e, t, n) {
    "use strict";

    var r = n(0),
        o = n(23)(!1),
        i = [].indexOf,
        u = !!i && 1 / [1].indexOf(1, -0) < 0;
    r(r.P + r.F * (u || !n(13)(i)), "Array", {
      indexOf: function (e) {
        return u ? i.apply(this, arguments) || 0 : o(this, e, arguments[1]);
      }
    });
  }, function (e, t, n) {
    var r = n(0);
    r(r.S, "Object", {
      create: n(52)
    });
  }, function (e, t, n) {
    "use strict";

    t.__esModule = !0, t["default"] = void 0, n(14), n(30), n(31), n(35), n(49), n(50);

    var r = n(5),
        o = function s(e) {
      return e && e.__esModule ? e : {
        "default": e
      };
    }(n(51));

    function i(e) {
      if (!e.element) throw new Error("element is not defined");
      if (!e.id) throw new Error("id is not defined");
      if (!e.source) throw new Error("source is not defined");
      Array.isArray(e.source) && (e.source = u(e.source)), (0, r.render)((0, r.createElement)(o["default"], e), e.element);
    }

    var u = function u(n) {
      return function (t, e) {
        e(n.filter(function (e) {
          return -1 !== e.toLowerCase().indexOf(t.toLowerCase());
        }));
      };
    };

    i.enhanceSelectElement = function (n) {
      if (!n.selectElement) throw new Error("selectElement is not defined");

      if (!n.source) {
        var e = [].filter.call(n.selectElement.options, function (e) {
          return e.value || n.preserveNullOptions;
        });
        n.source = e.map(function (e) {
          return e.textContent || e.innerText;
        });
      }

      if (n.onConfirm = n.onConfirm || function (t) {
        var e = [].filter.call(n.selectElement.options, function (e) {
          return (e.textContent || e.innerText) === t;
        })[0];
        e && (e.selected = !0);
      }, n.selectElement.value || n.defaultValue === undefined) {
        var t = n.selectElement.options[n.selectElement.options.selectedIndex];
        n.defaultValue = t.textContent || t.innerText;
      }

      n.name === undefined && (n.name = ""), n.id === undefined && (n.selectElement.id === undefined ? n.id = "" : n.id = n.selectElement.id), n.autoselect === undefined && (n.autoselect = !0);
      var r = document.createElement("div");
      n.selectElement.parentNode.insertBefore(r, n.selectElement), i(Object.assign({}, n, {
        element: r
      })), n.selectElement.style.display = "none", n.selectElement.id = n.selectElement.id + "-select";
    };

    var a = i;
    t["default"] = a;
  }, function (e, t, n) {
    e.exports = !n(3) && !n(4)(function () {
      return 7 != Object.defineProperty(n(15)("div"), "a", {
        get: function () {
          return 7;
        }
      }).a;
    });
  }, function (e, t, n) {
    var o = n(2);

    e.exports = function (e, t) {
      if (!o(e)) return e;
      var n, r;
      if (t && "function" == typeof (n = e.toString) && !o(r = n.call(e))) return r;
      if ("function" == typeof (n = e.valueOf) && !o(r = n.call(e))) return r;
      if (!t && "function" == typeof (n = e.toString) && !o(r = n.call(e))) return r;
      throw TypeError("Can't convert object to primitive value");
    };
  }, function (e, t) {
    e.exports = function (e, t) {
      return {
        enumerable: !(1 & e),
        configurable: !(2 & e),
        writable: !(4 & e),
        value: t
      };
    };
  }, function (e, t, n) {
    "use strict";

    var f = n(20),
        d = n(45),
        h = n(46),
        m = n(29),
        v = n(11),
        o = Object.assign;
    e.exports = !o || n(4)(function () {
      var e = {},
          t = {},
          n = Symbol(),
          r = "abcdefghijklmnopqrst";
      return e[n] = 7, r.split("").forEach(function (e) {
        t[e] = e;
      }), 7 != o({}, e)[n] || Object.keys(o({}, t)).join("") != r;
    }) ? function (e, t) {
      for (var n = m(e), r = arguments.length, o = 1, i = d.f, u = h.f; o < r;) for (var a, s = v(arguments[o++]), l = i ? f(s).concat(i(s)) : f(s), c = l.length, p = 0; p < c;) u.call(s, a = l[p++]) && (n[a] = s[a]);

      return n;
    } : o;
  }, function (e, t, n) {
    var u = n(17),
        a = n(21),
        s = n(23)(!1),
        l = n(26)("IE_PROTO");

    e.exports = function (e, t) {
      var n,
          r = a(e),
          o = 0,
          i = [];

      for (n in r) n != l && u(r, n) && i.push(n);

      for (; t.length > o;) u(r, n = t[o++]) && (~s(i, n) || i.push(n));

      return i;
    };
  }, function (e, t, n) {
    var r = n(25),
        o = Math.max,
        i = Math.min;

    e.exports = function (e, t) {
      return (e = r(e)) < 0 ? o(e + t, 0) : i(e, t);
    };
  }, function (e, t) {
    e.exports = !1;
  }, function (e, t) {
    t.f = Object.getOwnPropertySymbols;
  }, function (e, t) {
    t.f = {}.propertyIsEnumerable;
  }, function (e, t, n) {
    var r = n(48);

    e.exports = function (e, t) {
      return new (r(e))(t);
    };
  }, function (e, t, n) {
    var r = n(2),
        o = n(33),
        i = n(34)("species");

    e.exports = function (e) {
      var t;
      return o(e) && ("function" != typeof (t = e.constructor) || t !== Array && !o(t.prototype) || (t = undefined), r(t) && null === (t = t[i]) && (t = undefined)), t === undefined ? Array : t;
    };
  }, function (e, t, n) {
    "use strict";

    var r = n(0),
        o = n(32)(2);
    r(r.P + r.F * !n(13)([].filter, !0), "Array", {
      filter: function (e) {
        return o(this, e, arguments[1]);
      }
    });
  }, function (e, t, n) {
    var r = n(0);
    r(r.S, "Array", {
      isArray: n(33)
    });
  }, function (e, t, n) {
    "use strict";

    t.__esModule = !0, t["default"] = void 0, n(14), n(36), n(30), n(31), n(35), n(55), n(58);
    var $ = n(5),
        J = o(n(60)),
        r = o(n(61));

    function o(e) {
      return e && e.__esModule ? e : {
        "default": e
      };
    }

    function X() {
      return (X = Object.assign || function (e) {
        for (var t = 1; t < arguments.length; t++) {
          var n = arguments[t];

          for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r]);
        }

        return e;
      }).apply(this, arguments);
    }

    function i(e) {
      if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
      return e;
    }

    var u = {
      13: "enter",
      27: "escape",
      32: "space",
      38: "up",
      40: "down"
    };

    function Y() {
      return "undefined" != typeof navigator && !(!navigator.userAgent.match(/(iPod|iPhone|iPad)/g) || !navigator.userAgent.match(/AppleWebKit/g));
    }

    var a = function (n) {
      function e(e) {
        var t;
        return (t = n.call(this, e) || this).elementReferences = {}, t.state = {
          focused: null,
          hovered: null,
          menuOpen: !1,
          options: e.defaultValue ? [e.defaultValue] : [],
          query: e.defaultValue,
          validChoiceMade: !1,
          selected: null,
          ariaHint: !0
        }, t.handleComponentBlur = t.handleComponentBlur.bind(i(i(t))), t.handleKeyDown = t.handleKeyDown.bind(i(i(t))), t.handleUpArrow = t.handleUpArrow.bind(i(i(t))), t.handleDownArrow = t.handleDownArrow.bind(i(i(t))), t.handleEnter = t.handleEnter.bind(i(i(t))), t.handlePrintableKey = t.handlePrintableKey.bind(i(i(t))), t.handleListMouseLeave = t.handleListMouseLeave.bind(i(i(t))), t.handleOptionBlur = t.handleOptionBlur.bind(i(i(t))), t.handleOptionClick = t.handleOptionClick.bind(i(i(t))), t.handleOptionFocus = t.handleOptionFocus.bind(i(i(t))), t.handleOptionMouseDown = t.handleOptionMouseDown.bind(i(i(t))), t.handleOptionMouseEnter = t.handleOptionMouseEnter.bind(i(i(t))), t.handleInputBlur = t.handleInputBlur.bind(i(i(t))), t.handleInputChange = t.handleInputChange.bind(i(i(t))), t.handleInputFocus = t.handleInputFocus.bind(i(i(t))), t.pollInputElement = t.pollInputElement.bind(i(i(t))), t.getDirectInputChanges = t.getDirectInputChanges.bind(i(i(t))), t;
      }

      (function r(e, t) {
        e.prototype = Object.create(t.prototype), (e.prototype.constructor = e).__proto__ = t;
      })(e, n);

      var t = e.prototype;
      return t.isQueryAnOption = function (e, t) {
        var n = this;
        return -1 !== t.map(function (e) {
          return n.templateInputValue(e).toLowerCase();
        }).indexOf(e.toLowerCase());
      }, t.componentDidMount = function () {
        this.pollInputElement();
      }, t.componentWillUnmount = function () {
        clearTimeout(this.$pollInput);
      }, t.pollInputElement = function () {
        var e = this;
        this.getDirectInputChanges(), this.$pollInput = setTimeout(function () {
          e.pollInputElement();
        }, 100);
      }, t.getDirectInputChanges = function () {
        var e = this.elementReferences[-1];
        e && e.value !== this.state.query && this.handleInputChange({
          target: {
            value: e.value
          }
        });
      }, t.componentDidUpdate = function (e, t) {
        var n = this.state.focused,
            r = null === n,
            o = t.focused !== n;
        o && !r && this.elementReferences[n].focus();
        var i = -1 === n,
            u = o && null === t.focused;

        if (i && u) {
          var a = this.elementReferences[n];
          a.setSelectionRange(0, a.value.length);
        }
      }, t.hasAutoselect = function () {
        return !Y() && this.props.autoselect;
      }, t.templateInputValue = function (e) {
        var t = this.props.templates && this.props.templates.inputValue;
        return t ? t(e) : e;
      }, t.templateSuggestion = function (e) {
        var t = this.props.templates && this.props.templates.suggestion;
        return t ? t(e) : e;
      }, t.handleComponentBlur = function (e) {
        var t,
            n = this.state,
            r = n.options,
            o = n.query,
            i = n.selected;
        this.props.confirmOnBlur ? (t = e.query || o, this.props.onConfirm(r[i])) : t = o, this.setState({
          focused: null,
          menuOpen: e.menuOpen || !1,
          query: t,
          selected: null,
          validChoiceMade: this.isQueryAnOption(t, r)
        });
      }, t.handleListMouseLeave = function (e) {
        this.setState({
          hovered: null
        });
      }, t.handleOptionBlur = function (e, t) {
        var n = this.state,
            r = n.focused,
            o = n.menuOpen,
            i = n.options,
            u = n.selected,
            a = null === e.relatedTarget,
            s = e.relatedTarget === this.elementReferences[-1],
            l = r !== t && -1 !== r;

        if (!l && a || !(l || s)) {
          var c = o && Y();
          this.handleComponentBlur({
            menuOpen: c,
            query: this.templateInputValue(i[u])
          });
        }
      }, t.handleInputBlur = function (e) {
        var t = this.state,
            n = t.focused,
            r = t.menuOpen,
            o = t.options,
            i = t.query,
            u = t.selected;

        if (!(-1 !== n)) {
          var a = r && Y(),
              s = Y() ? i : this.templateInputValue(o[u]);
          this.handleComponentBlur({
            menuOpen: a,
            query: s
          });
        }
      }, t.handleInputChange = function (e) {
        var n = this,
            t = this.props,
            r = t.minLength,
            o = t.source,
            i = t.showAllValues,
            u = this.hasAutoselect(),
            a = e.target.value,
            s = 0 === a.length,
            l = this.state.query.length !== a.length,
            c = a.length >= r;
        this.setState({
          query: a,
          ariaHint: s
        }), i || !s && l && c ? o(a, function (e) {
          var t = 0 < e.length;
          n.setState({
            menuOpen: t,
            options: e,
            selected: u && t ? 0 : -1,
            validChoiceMade: !1
          });
        }) : !s && c || this.setState({
          menuOpen: !1,
          options: []
        });
      }, t.handleInputClick = function (e) {
        this.handleInputChange(e);
      }, t.handleInputFocus = function (e) {
        var t = this.state,
            n = t.query,
            r = t.validChoiceMade,
            o = t.options,
            i = this.props.minLength,
            u = !r && n.length >= i && 0 < o.length;
        u ? this.setState(function (e) {
          var t = e.menuOpen;
          return {
            focused: -1,
            menuOpen: u || t,
            selected: -1
          };
        }) : this.setState({
          focused: -1
        });
      }, t.handleOptionFocus = function (e) {
        this.setState({
          focused: e,
          hovered: null,
          selected: e
        });
      }, t.handleOptionMouseEnter = function (e, t) {
        Y() || this.setState({
          hovered: t
        });
      }, t.handleOptionClick = function (e, t) {
        var n = this.state.options[t],
            r = this.templateInputValue(n);
        this.props.onConfirm(n), this.setState({
          focused: -1,
          hovered: null,
          menuOpen: !1,
          query: r,
          selected: -1,
          validChoiceMade: !0
        }), this.forceUpdate();
      }, t.handleOptionMouseDown = function (e) {
        e.preventDefault();
      }, t.handleUpArrow = function (e) {
        e.preventDefault();
        var t = this.state,
            n = t.menuOpen,
            r = t.selected;
        -1 !== r && n && this.handleOptionFocus(r - 1);
      }, t.handleDownArrow = function (e) {
        var t = this;
        if (e.preventDefault(), this.props.showAllValues && !1 === this.state.menuOpen) e.preventDefault(), this.props.source("", function (e) {
          t.setState({
            menuOpen: !0,
            options: e,
            selected: 0,
            focused: 0,
            hovered: null
          });
        });else if (!0 === this.state.menuOpen) {
          var n = this.state,
              r = n.menuOpen,
              o = n.options,
              i = n.selected;
          i !== o.length - 1 && r && this.handleOptionFocus(i + 1);
        }
      }, t.handleSpace = function (e) {
        var t = this;
        this.props.showAllValues && !1 === this.state.menuOpen && "" === this.state.query && (e.preventDefault(), this.props.source("", function (e) {
          t.setState({
            menuOpen: !0,
            options: e
          });
        })), -1 !== this.state.focused && (e.preventDefault(), this.handleOptionClick(e, this.state.focused));
      }, t.handleEnter = function (e) {
        this.state.menuOpen && (e.preventDefault(), 0 <= this.state.selected && this.handleOptionClick(e, this.state.selected));
      }, t.handlePrintableKey = function (e) {
        var t = this.elementReferences[-1];
        e.target === t || t.focus();
      }, t.handleKeyDown = function (e) {
        switch (u[e.keyCode]) {
          case "up":
            this.handleUpArrow(e);
            break;

          case "down":
            this.handleDownArrow(e);
            break;

          case "space":
            this.handleSpace(e);
            break;

          case "enter":
            this.handleEnter(e);
            break;

          case "escape":
            this.handleComponentBlur({
              query: this.state.query
            });
            break;

          default:
            (function t(e) {
              return 47 < e && e < 58 || 32 === e || 8 === e || 64 < e && e < 91 || 95 < e && e < 112 || 185 < e && e < 193 || 218 < e && e < 223;
            })(e.keyCode) && this.handlePrintableKey(e);
        }
      }, t.render = function () {
        var e,
            i = this,
            t = this.props,
            n = t.cssNamespace,
            r = t.displayMenu,
            u = t.id,
            o = t.minLength,
            a = t.name,
            s = t.placeholder,
            l = t.required,
            c = t.showAllValues,
            p = t.tNoResults,
            f = t.tStatusQueryTooShort,
            d = t.tStatusNoResults,
            h = t.tStatusSelectedOption,
            m = t.tStatusResults,
            v = t.tAssistiveHint,
            y = t.dropdownArrow,
            g = this.state,
            _ = g.focused,
            b = g.hovered,
            w = g.menuOpen,
            x = g.options,
            O = g.query,
            C = g.selected,
            S = g.ariaHint,
            E = g.validChoiceMade,
            M = this.hasAutoselect(),
            N = -1 === _,
            I = 0 === x.length,
            k = 0 !== O.length,
            A = O.length >= o,
            P = this.props.showNoOptionsFound && N && I && k && A,
            j = n + "__wrapper",
            L = n + "__input",
            T = null !== _ ? " " + L + "--focused" : "",
            B = this.props.showAllValues ? " " + L + "--show-all-values" : " " + L + "--default",
            D = n + "__dropdown-arrow-down",
            F = -1 !== _ && null !== _,
            R = n + "__menu",
            U = R + "--" + r,
            V = R + "--" + (w || P ? "visible" : "hidden"),
            q = n + "__option",
            W = n + "__hint",
            H = this.templateInputValue(x[C]),
            K = H && 0 === H.toLowerCase().indexOf(O.toLowerCase()) && M ? O + H.substr(O.length) : "",
            Q = u + "__assistiveHint",
            z = S ? {
          "aria-describedby": Q
        } : null;
        return c && "string" == typeof (e = y({
          className: D
        })) && (e = (0, $.createElement)("div", {
          className: n + "__dropdown-arrow-down-wrapper",
          dangerouslySetInnerHTML: {
            __html: e
          }
        })), (0, $.createElement)("div", {
          className: j,
          onKeyDown: this.handleKeyDown
        }, (0, $.createElement)(J["default"], {
          id: u,
          length: x.length,
          queryLength: O.length,
          minQueryLength: o,
          selectedOption: this.templateInputValue(x[C]),
          selectedOptionIndex: C,
          validChoiceMade: E,
          isInFocus: null !== this.state.focused,
          tQueryTooShort: f,
          tNoResults: d,
          tSelectedOption: h,
          tResults: m
        }), K && (0, $.createElement)("span", null, (0, $.createElement)("input", {
          className: W,
          readonly: !0,
          tabIndex: "-1",
          value: K
        })), (0, $.createElement)("input", X({
          "aria-expanded": w ? "true" : "false",
          "aria-activedescendant": !!F && u + "__option--" + _,
          "aria-owns": u + "__listbox",
          "aria-autocomplete": this.hasAutoselect() ? "both" : "list"
        }, z, {
          autoComplete: "off",
          className: "" + L + T + B,
          id: u,
          onClick: function (e) {
            return i.handleInputClick(e);
          },
          onBlur: this.handleInputBlur
        }, function G(e) {
          return {
            onInput: e
          };
        }(this.handleInputChange), {
          onFocus: this.handleInputFocus,
          name: a,
          placeholder: s,
          ref: function (e) {
            i.elementReferences[-1] = e;
          },
          type: "text",
          role: "combobox",
          required: l,
          value: O
        })), e, (0, $.createElement)("ul", {
          className: R + " " + U + " " + V,
          onMouseLeave: function (e) {
            return i.handleListMouseLeave(e);
          },
          id: u + "__listbox",
          role: "listbox"
        }, x.map(function (e, t) {
          var n = (-1 === _ ? C === t : _ === t) && null === b ? " " + q + "--focused" : "",
              r = t % 2 ? " " + q + "--odd" : "",
              o = Y() ? "<span id=" + u + "__option-suffix--" + t + ' style="border:0;clip:rect(0 0 0 0);height:1px;marginBottom:-1px;marginRight:-1px;overflow:hidden;padding:0;position:absolute;whiteSpace:nowrap;width:1px"> ' + (t + 1) + " of " + x.length + "</span>" : "";
          return (0, $.createElement)("li", {
            "aria-selected": _ === t ? "true" : "false",
            className: "" + q + n + r,
            dangerouslySetInnerHTML: {
              __html: i.templateSuggestion(e) + o
            },
            id: u + "__option--" + t,
            key: t,
            onBlur: function (e) {
              return i.handleOptionBlur(e, t);
            },
            onClick: function (e) {
              return i.handleOptionClick(e, t);
            },
            onMouseDown: i.handleOptionMouseDown,
            onMouseEnter: function (e) {
              return i.handleOptionMouseEnter(e, t);
            },
            ref: function (e) {
              i.elementReferences[t] = e;
            },
            role: "option",
            tabIndex: "-1",
            "aria-posinset": t + 1,
            "aria-setsize": x.length
          });
        }), P && (0, $.createElement)("li", {
          className: q + " " + q + "--no-results"
        }, p())), (0, $.createElement)("span", {
          id: Q,
          style: {
            display: "none"
          }
        }, v()));
      }, e;
    }($.Component);

    (t["default"] = a).defaultProps = {
      autoselect: !1,
      cssNamespace: "autocomplete",
      defaultValue: "",
      displayMenu: "inline",
      minLength: 0,
      name: "input-autocomplete",
      placeholder: "",
      onConfirm: function () {},
      confirmOnBlur: !0,
      showNoOptionsFound: !0,
      showAllValues: !1,
      required: !1,
      tNoResults: function () {
        return "No results found";
      },
      tAssistiveHint: function () {
        return "When autocomplete results are available use up and down arrows to review and enter to select.  Touch device users, explore by touch or with swipe gestures.";
      },
      dropdownArrow: r["default"]
    };
  }, function (e, t, r) {
    var o = r(9),
        i = r(53),
        u = r(28),
        a = r(26)("IE_PROTO"),
        s = function () {},
        l = "prototype",
        c = function () {
      var e,
          t = r(15)("iframe"),
          n = u.length;

      for (t.style.display = "none", r(54).appendChild(t), t.src = "javascript:", (e = t.contentWindow.document).open(), e.write("<script>document.F=Object<\/script>"), e.close(), c = e.F; n--;) delete c[l][u[n]];

      return c();
    };

    e.exports = Object.create || function (e, t) {
      var n;
      return null !== e ? (s[l] = o(e), n = new s(), s[l] = null, n[a] = e) : n = c(), t === undefined ? n : i(n, t);
    };
  }, function (e, t, n) {
    var u = n(8),
        a = n(9),
        s = n(20);
    e.exports = n(3) ? Object.defineProperties : function (e, t) {
      a(e);

      for (var n, r = s(t), o = r.length, i = 0; i < o;) u.f(e, n = r[i++], t[n]);

      return e;
    };
  }, function (e, t, n) {
    var r = n(1).document;
    e.exports = r && r.documentElement;
  }, function (e, t, n) {
    var r = n(0);
    r(r.P, "Function", {
      bind: n(56)
    });
  }, function (e, t, n) {
    "use strict";

    var i = n(19),
        u = n(2),
        a = n(57),
        s = [].slice,
        l = {};

    e.exports = Function.bind || function (t) {
      var n = i(this),
          r = s.call(arguments, 1),
          o = function () {
        var e = r.concat(s.call(arguments));
        return this instanceof o ? function (e, t, n) {
          if (!(t in l)) {
            for (var r = [], o = 0; o < t; o++) r[o] = "a[" + o + "]";

            l[t] = Function("F,a", "return new F(" + r.join(",") + ")");
          }

          return l[t](e, n);
        }(n, e.length, e) : a(n, e, t);
      };

      return u(n.prototype) && (o.prototype = n.prototype), o;
    };
  }, function (e, t) {
    e.exports = function (e, t, n) {
      var r = n === undefined;

      switch (t.length) {
        case 0:
          return r ? e() : e.call(n);

        case 1:
          return r ? e(t[0]) : e.call(n, t[0]);

        case 2:
          return r ? e(t[0], t[1]) : e.call(n, t[0], t[1]);

        case 3:
          return r ? e(t[0], t[1], t[2]) : e.call(n, t[0], t[1], t[2]);

        case 4:
          return r ? e(t[0], t[1], t[2], t[3]) : e.call(n, t[0], t[1], t[2], t[3]);
      }

      return e.apply(n, t);
    };
  }, function (e, t, n) {
    n(59)("match", 1, function (r, o, e) {
      return [function (e) {
        "use strict";

        var t = r(this),
            n = e == undefined ? undefined : e[o];
        return n !== undefined ? n.call(e, t) : new RegExp(e)[o](String(t));
      }, e];
    });
  }, function (e, t, n) {
    "use strict";

    var a = n(7),
        s = n(16),
        l = n(4),
        c = n(12),
        p = n(34);

    e.exports = function (t, e, n) {
      var r = p(t),
          o = n(c, r, ""[t]),
          i = o[0],
          u = o[1];
      l(function () {
        var e = {};
        return e[r] = function () {
          return 7;
        }, 7 != ""[t](e);
      }) && (s(String.prototype, t, i), a(RegExp.prototype, r, 2 == e ? function (e, t) {
        return u.call(e, this, t);
      } : function (e) {
        return u.call(e, this);
      }));
    };
  }, function (e, t, n) {
    "use strict";

    t.__esModule = !0, t["default"] = void 0, n(36);

    var _ = n(5);

    var r = function r(o, i, u) {
      var a;
      return function () {
        var e = this,
            t = arguments,
            n = function n() {
          a = null, u || o.apply(e, t);
        },
            r = u && !a;

        clearTimeout(a), a = setTimeout(n, i), r && o.apply(e, t);
      };
    },
        o = function (o) {
      function e() {
        for (var e, t = arguments.length, n = new Array(t), r = 0; r < t; r++) n[r] = arguments[r];

        return (e = o.call.apply(o, [this].concat(n)) || this).state = {
          bump: !1,
          debounced: !1
        }, e;
      }

      (function n(e, t) {
        e.prototype = Object.create(t.prototype), (e.prototype.constructor = e).__proto__ = t;
      })(e, o);

      var t = e.prototype;
      return t.componentWillMount = function () {
        var e = this;
        this.debounceStatusUpdate = r(function () {
          if (!e.state.debounced) {
            var t = !e.props.isInFocus || e.props.validChoiceMade;
            e.setState(function (e) {
              return {
                bump: !e.bump,
                debounced: !0,
                silenced: t
              };
            });
          }
        }, 1400);
      }, t.componentWillReceiveProps = function (e) {
        e.queryLength;
        this.setState({
          debounced: !1
        });
      }, t.render = function () {
        var e = this.props,
            t = e.id,
            n = e.length,
            r = e.queryLength,
            o = e.minQueryLength,
            i = e.selectedOption,
            u = e.selectedOptionIndex,
            a = e.tQueryTooShort,
            s = e.tNoResults,
            l = e.tSelectedOption,
            c = e.tResults,
            p = this.state,
            f = p.bump,
            d = p.debounced,
            h = p.silenced,
            m = r < o,
            v = 0 === n,
            y = i ? l(i, n, u) : "",
            g = null;
        return g = m ? a(o) : v ? s() : c(n, y), this.debounceStatusUpdate(), (0, _.createElement)("div", {
          style: {
            border: "0",
            clip: "rect(0 0 0 0)",
            height: "1px",
            marginBottom: "-1px",
            marginRight: "-1px",
            overflow: "hidden",
            padding: "0",
            position: "absolute",
            whiteSpace: "nowrap",
            width: "1px"
          }
        }, (0, _.createElement)("div", {
          id: t + "__status--A",
          role: "status",
          "aria-atomic": "true",
          "aria-live": "polite"
        }, !h && d && f ? g : ""), (0, _.createElement)("div", {
          id: t + "__status--B",
          role: "status",
          "aria-atomic": "true",
          "aria-live": "polite"
        }, h || !d || f ? "" : g));
      }, e;
    }(_.Component);

    (t["default"] = o).defaultProps = {
      tQueryTooShort: function (e) {
        return "Type in " + e + " or more characters for results";
      },
      tNoResults: function () {
        return "No search results";
      },
      tSelectedOption: function (e, t, n) {
        return e + " " + (n + 1) + " of " + t + " is highlighted";
      },
      tResults: function (e, t) {
        return e + " " + (1 === e ? "result" : "results") + " " + (1 === e ? "is" : "are") + " available. " + t;
      }
    };
  }, function (e, t, n) {
    "use strict";

    t.__esModule = !0, t["default"] = void 0;

    var r = n(5),
        o = function i(e) {
      var t = e.className;
      return (0, r.createElement)("svg", {
        version: "1.1",
        xmlns: "http://www.w3.org/2000/svg",
        className: t,
        focusable: "false"
      }, (0, r.createElement)("g", {
        stroke: "none",
        fill: "none",
        "fill-rule": "evenodd"
      }, (0, r.createElement)("polygon", {
        fill: "#000000",
        points: "0 0 22 0 11 17"
      })));
    };

    t["default"] = o;
  }])["default"];
});
},{}],"TAPd":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _grid = _interopRequireDefault(require("./grid"));

var _loadData = _interopRequireDefault(require("./load-data"));

require("./pudding-chart/colors-chart");

require("./pudding-chart/bar");

var _miniGrid = _interopRequireDefault(require("./miniGrid"));

var _enterView = _interopRequireDefault(require("enter-view"));

var _accessibleAutocomplete = _interopRequireDefault(require("accessible-autocomplete"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance"); }

function _iterableToArray(iter) { if (Symbol.iterator in Object(iter) || Object.prototype.toString.call(iter) === "[object Arguments]") return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = new Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } }

var data = null;
var yearData = null;
var colorChart = null;
var $colorChartDiv = d3.select('#chart');
var $overlay = d3.select('.overlay');
var yearChart = null;
var $yearChartDiv = d3.select('#year-chart');
var $candidateNameSpan = d3.selectAll('.cand-hover');
var $allCheckboxes = d3.selectAll('.input__check');
var $checkbox_party_r = d3.selectAll('#party-r');
var $checkbox_party_d = d3.selectAll('#party-d');
var $checkbox_party_t = d3.selectAll('#party-t');
var $checkbox_color_rwb = d3.selectAll('#color-rwb');
var $checkbox_color_nrwb = d3.selectAll('#color-nrwb');
var $checkbox_race_w = d3.selectAll('#race-w');
var $checkbox_race_nw = d3.selectAll('#race-nw');
var $checkbox_gender_m = d3.selectAll('#gender-m');
var $checkbox_gender_nm = d3.selectAll('#gender-nm');
var $reset = d3.select('.reset');
var $inputText = d3.select('#my-autocomplete'); // INTERACTIONS

function resetChart() {
  var $autocompleteInput = d3.select('.autocomplete__wrapper input');
  $autocompleteInput.node().value = '';
  d3.selectAll('.candidate').transition().duration(200).ease(d3.easeLinear).style('opacity', 1).style('pointer-events', 'auto');

  if (!$checkbox_party_d.node().checked) {
    $checkbox_party_d.node().click();
  }

  if (!$checkbox_party_r.node().checked) {
    $checkbox_party_r.node().click();
  }

  if (!$checkbox_party_t.node().checked) {
    $checkbox_party_t.node().click();
  }

  if (!$checkbox_color_rwb.node().checked) {
    $checkbox_color_rwb.node().click();
  }

  if (!$checkbox_color_nrwb.node().checked) {
    $checkbox_color_nrwb.node().click();
  }

  if (!$checkbox_race_w.node().checked) {
    $checkbox_race_w.node().click();
  }

  if (!$checkbox_race_nw.node().checked) {
    $checkbox_race_nw.node().click();
  }

  if (!$checkbox_gender_m.node().checked) {
    $checkbox_gender_m.node().click();
  }

  if (!$checkbox_gender_nm.node().checked) {
    $checkbox_gender_nm.node().click();
  }
}

function highlightName() {
  var $name = d3.select(this).attr('id').split('-')[0];
  var $parent = d3.select(this.parentNode).attr('id').split('-')[0];
  var $logo = d3.selectAll(".logoSmall-".concat($name));
  var $logoDivs = d3.selectAll("#".concat($parent, " .logoSmall"));
  $logoDivs.transition().duration(200).ease(d3.easeLinear).style('opacity', 0.2).style('filter', 'grayscale(100%)');
  $logo.transition().duration(200).ease(d3.easeLinear).style('opacity', 1).style('filter', 'none');
  $logo.classed('is-highlighted', true);
}

function dehighlightName() {
  var $logoDivs = d3.selectAll('.logoSmall');
  $logoDivs.transition().duration(200).ease(d3.easeLinear).style('opacity', 1).style('filter', 'none');
  $logoDivs.classed('is-highlighted', false);
} // FILTERS


function checkParty() {
  var $checkbox_party_r_status = $checkbox_party_r.node().checked;
  var $checkbox_party_d_status = $checkbox_party_d.node().checked;
  var $checkbox_party_t_status = $checkbox_party_t.node().checked;

  if ($checkbox_party_r_status === false) {
    d3.selectAll('.candidate_party-Republican').transition().duration(200).ease(d3.easeLinear).style('opacity', 0.2).style('pointer-events', 'none');
  }

  if ($checkbox_party_d_status === false) {
    d3.selectAll('.candidate_party-Democratic').transition().duration(200).ease(d3.easeLinear).style('opacity', 0.2).style('pointer-events', 'none');
  }

  if ($checkbox_party_t_status === false) {
    d3.selectAll('.candidate_party-Third').transition().duration(200).ease(d3.easeLinear).style('opacity', 0.2).style('pointer-events', 'none');
  }
}

function checkColor() {
  var $checkbox_color_rwb_status = $checkbox_color_rwb.node().checked;
  var $checkbox_color_nrwb_status = $checkbox_color_nrwb.node().checked;

  if ($checkbox_color_rwb_status === false) {
    d3.selectAll('.candidate_RWB-Y').transition().duration(200).ease(d3.easeLinear).style('opacity', 0.2).style('pointer-events', 'none');
  }

  if ($checkbox_color_nrwb_status === false) {
    d3.selectAll('.candidate_RWB-N').transition().duration(200).ease(d3.easeLinear).style('opacity', 0.2).style('pointer-events', 'none');
  }
}

function checkRace() {
  var $checkbox_race_w_status = $checkbox_race_w.node().checked;
  var $checkbox_race_nw_status = $checkbox_race_nw.node().checked;

  if ($checkbox_race_w_status === false) {
    d3.selectAll('.candidate_white-Y').transition().duration(200).ease(d3.easeLinear).style('opacity', 0.2).style('pointer-events', 'none');
  }

  if ($checkbox_race_nw_status === false) {
    d3.selectAll('.candidate_white-N').transition().duration(200).ease(d3.easeLinear).style('opacity', 0.2).style('pointer-events', 'none');
  }
}

function checkGender() {
  var $checkbox_gender_m_status = $checkbox_gender_m.node().checked;
  var $checkbox_gender_nm_status = $checkbox_gender_nm.node().checked;

  if ($checkbox_gender_m_status === false) {
    d3.selectAll('.candidate_male-Y').transition().duration(200).ease(d3.easeLinear).style('opacity', 0.2).style('pointer-events', 'none');
  }

  if ($checkbox_gender_nm_status === false) {
    d3.selectAll('.candidate_male-N').transition().duration(200).ease(d3.easeLinear).style('opacity', 0.2).style('pointer-events', 'none');
  }
}

function checkCheckboxes() {
  d3.selectAll('.candidate').transition().duration(200).ease(d3.easeLinear).style('opacity', 1).style('pointer-events', 'auto');
  checkParty();
  checkColor();
  checkRace();
  checkGender();
} // AUTOCOMPLETE


function setupCandidateSearch() {
  var onlyNames = data.map(function (d) {
    return d.name;
  });
  onlyNames = _toConsumableArray(new Set(onlyNames));
  (0, _accessibleAutocomplete.default)({
    defaultValue: '',
    element: document.querySelector('#autocomplete'),
    id: 'my-autocomplete',
    source: onlyNames,
    displayMenu: 'overlay',
    minLength: 3,
    confirmOnBlur: true,
    onConfirm: function onConfirm(name) {
      highlightCandidate(name);
    }
  });
}

function highlightCandidate(name) {
  if (name) {
    var nameStripped = name.replace(/\s+/g, '').replace(/\./g, '').replace(/\'/g, '');
    d3.selectAll('.candidate').transition().duration(200).ease(d3.easeLinear).style('opacity', 0.2).style('pointer-events', 'none');
    d3.selectAll(".candidate_".concat(nameStripped)).transition().duration(200).ease(d3.easeLinear).style('opacity', 1).style('pointer-events', 'auto');
  }
} // CHARTS


function setupColorChart() {
  colorChart = $colorChartDiv.datum(data).puddingColorChart();
}

function setupYearChart() {
  yearChart = $yearChartDiv.datum(yearData).puddingBarChart();
}

function resize() {}

function init() {
  (0, _loadData.default)(['colors.csv', 'years.csv']).then(function (result) {
    data = result[0];
    yearData = result[1];

    _grid.default.init(data);

    setupYearChart();

    _miniGrid.default.init(data, 'allMin');

    _miniGrid.default.init(data, 'race');

    _miniGrid.default.init(data, 'gender');

    _miniGrid.default.init(data, 'minWomen');

    setupColorChart();
    (0, _enterView.default)({
      selector: '.methods',
      enter: function enter(el) {
        $overlay.classed('is-visible', false);
      },
      exit: function exit(el) {
        $overlay.classed('is-visible', true);
      },
      offset: 0.6
    }); // INTERACTIONS

    $candidateNameSpan.on('mouseenter', highlightName);
    $candidateNameSpan.on('click', highlightName);
    $candidateNameSpan.on('mouseleave', dehighlightName); // FILTERS & SEARCH

    setupCandidateSearch();
    $allCheckboxes.on('change', checkCheckboxes);
    $reset.on('click', resetChart);
  }).catch(console.error);
}

var _default = {
  init: init,
  resize: resize
};
exports.default = _default;
},{"./grid":"K8rx","./load-data":"xZJw","./pudding-chart/colors-chart":"V7o5","./pudding-chart/bar":"ia5p","./miniGrid":"miniGrid.js","enter-view":"RZIL","accessible-autocomplete":"fTMh"}],"v9Q8":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var fallbackData = [{
  image: "2018_02_stand-up",
  url: "2018/02/stand-up",
  hed: "The Structure of Stand-Up Comedy"
}, {
  image: "2018_04_birthday-paradox",
  url: "2018/04/birthday-paradox",
  hed: "The Birthday Paradox Experiment"
}, {
  image: "2018_11_boy-bands",
  url: "2018/11/boy-bands",
  hed: "Internet Boy Band Database"
}, {
  image: "2018_08_pockets",
  url: "2018/08/pockets",
  hed: "Women’s Pockets are Inferior"
}];
var storyData = null;

function loadJS(src, cb) {
  var ref = document.getElementsByTagName("script")[0];
  var script = document.createElement("script");
  script.src = src;
  script.async = true;
  ref.parentNode.insertBefore(script, ref);

  if (cb && typeof cb === "function") {
    script.onload = cb;
  }

  return script;
}

function loadStories(cb) {
  var request = new XMLHttpRequest();
  var v = Date.now();
  var url = "https://pudding.cool/assets/data/stories.json?v=".concat(v);
  request.open("GET", url, true);

  request.onload = function () {
    if (request.status >= 200 && request.status < 400) {
      var data = JSON.parse(request.responseText);
      cb(data);
    } else cb(fallbackData);
  };

  request.onerror = function () {
    return cb(fallbackData);
  };

  request.send();
}

function createLink(d) {
  return "\n\t<a class='footer-recirc__article' href='https://pudding.cool/".concat(d.url, "' target='_blank' rel='noopener'>\n\t\t<img class='article__img' src='https://pudding.cool/common/assets/thumbnails/640/").concat(d.image, ".jpg' alt='").concat(d.hed, "'>\n\t\t<p class='article__headline'>").concat(d.hed, "</p>\n\t</a>\n\t");
}

function recircHTML() {
  var url = window.location.href;
  var html = storyData.filter(function (d) {
    return !url.includes(d.url);
  }).slice(0, 4).map(createLink).join("");
  d3.select(".pudding-footer .footer-recirc__articles").html(html);
}

function init() {
  loadStories(function (data) {
    storyData = data;
    recircHTML();
  });
}

var _default = {
  init: init
};
exports.default = _default;
},{}],"epB2":[function(require,module,exports) {
"use strict";

var _lodash = _interopRequireDefault(require("lodash.debounce"));

var _isMobile = _interopRequireDefault(require("./utils/is-mobile"));

var _linkFix = _interopRequireDefault(require("./utils/link-fix"));

var _graphic = _interopRequireDefault(require("./graphic"));

var _footer = _interopRequireDefault(require("./footer"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/* global d3 */
var $body = d3.select("body");
var previousWidth = 0;

function resize() {
  // only do resize on width changes, not height
  // (remove the conditional if you want to trigger on height change)
  var width = $body.node().offsetWidth;

  if (previousWidth !== width) {
    previousWidth = width;

    _graphic.default.resize();
  }
}

function setupStickyHeader() {
  var $header = $body.select("header");

  if ($header.classed("is-sticky")) {
    var $menu = $body.select(".header__menu");
    var $toggle = $body.select(".header__toggle");
    $toggle.on("click", function () {
      var visible = $menu.classed("is-visible");
      $menu.classed("is-visible", !visible);
      $toggle.classed("is-visible", !visible);
    });
  }
}

function init() {
  // adds rel="noopener" to all target="_blank" links
  (0, _linkFix.default)(); // add mobile class to body tag

  $body.classed("is-mobile", _isMobile.default.any()); // setup resize event

  window.addEventListener("resize", (0, _lodash.default)(resize, 150)); // setup sticky header menu

  setupStickyHeader(); // kick off graphic code

  _graphic.default.init(); // load footer stories


  _footer.default.init();
}

init();
},{"lodash.debounce":"or4r","./utils/is-mobile":"WEtf","./utils/link-fix":"U9xJ","./graphic":"TAPd","./footer":"v9Q8"}]},{},["epB2"], null)
//# sourceMappingURL=/main.js.map